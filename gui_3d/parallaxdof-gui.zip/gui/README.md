# ParallaxDoF Studio

GUI w PyGTK4 do pluginu GStreamer **gst-parallaxdof** (efekt 2.5D „mimoza
transwektorowa”): ręczne dostrajanie wszystkich parametrów, presety wbudowane
i własne, preanaliza głębi/ruchu z cache, test-run na wybranym zakresie
czasowym, podgląd na żywo w trybie porównawczym (obok siebie / jeden nad
drugim) z korektą parametrów w locie — zarówno podczas podglądu, jak i
podczas właściwego kodowania — oraz osobne, pełnoekranowe okno przeglądu
wyników z podpisami, zaznaczaniem zakresu powtarzania (IN/OUT) i pętlą.

## Wymagania systemowe

Twój plugin (`libgstparallaxdof.so`) musi być już zbudowany — tak jak w
`gst-parallaxdof-maska.zip`, którego używałem do testów. Oprócz tego:

- Python ≥ 3.10
- PyGObject (`python3-gi`) z GTK 4 i GStreamer 1.0:
  `gir1.2-gtk-4.0`, `gir1.2-gstreamer-1.0`, `gir1.2-gst-plugins-base-1.0`,
  `gir1.2-gst-plugins-bad-1.0`
- GStreamer: `gstreamer1.0-plugins-base`, `-good`, `-bad`, `-ugly`,
  `gstreamer1.0-libav` (audio/wideo, enkodery x264/x265/vp9, muxery
  mp4/mkv/webm), `gstreamer1.0-tools` (przydatne do diagnostyki)

Na Debian/Ubuntu (Solus/ChimeraOS/AerynOS — użyj odpowiednika w swoim menedżerze
pakietów, nazwy pakietów GStreamera są zwykle bardzo podobne):

```bash
sudo apt install python3-gi python3-gi-cairo \
    gir1.2-gtk-4.0 gir1.2-gstreamer-1.0 gir1.2-gst-plugins-base-1.0 gir1.2-gst-plugins-bad-1.0 \
    gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad \
    gstreamer1.0-plugins-ugly gstreamer1.0-libav gstreamer1.0-tools
```

## Instalacja

Rozpakuj ten folder (`gui/`) **wewnątrz** katalogu swojego projektu pluginu,
obok `src/` i `build/`:

```
gst-parallaxdof/
├── src/gstparallaxdof.cpp
├── build/libgstparallaxdof.so      ← Twój już zbudowany plugin
└── gui/                            ← ten folder
    └── pdofgui/...
```

GUI samo znajdzie `build/libgstparallaxdof.so` (szuka go względem własnej
lokalizacji). Jeśli trzymasz plugin gdzie indziej, ustaw zmienną środowiskową:

```bash
export PDOF_PLUGIN_DIR=/ścieżka/do/gst-parallaxdof/build
```

## Uruchomienie

```bash
cd gst-parallaxdof/gui
python3 -m pdofgui
```

Przy pierwszym uruchomieniu kliknij ikonę folderu (lewy górny róg) i wybierz
plik wideo. Ostatnio otwarty plik i folder wyjściowy zapamiętywane są w
`~/.config/parallaxdof-gui/`.

## Jak to jest zorganizowane

- **Wariant A / Wariant B** — dwa niezależne komplety suwaków parametrów
  pluginu, pogrupowane (efekt podstawowy, pasma głębi, wiggle 3D, detal
  lokalny, tryb realtime, kwantyzacja ruchu). Suwaki wymagające
  preanalizy głębi/ruchu są wyszarzane, gdy dane nie są dostępne dla
  bieżącego zakresu testu.
- **Preanaliza** — liczy mapę głębi i (opcjonalnie) realny ruch
  (Farneback optical flow) dla zakresu testu lub całego pliku, z
  podręcznym cache na dysku (klucz: plik + parametry analizatora +
  zakres). Bez tego kroku efekt działa w trybie realtime (uproszczona
  estymacja w locie, zgodnie z tym, co robi plugin bez `depth-file`/
  `motion-file`).
- **Eksport** — test-run (kodowanie tylko zakresu testu) lub cały plik,
  wybór wariantów do zakodowania (Oryginał/A/B), kodek/kontener/jakość/
  audio, folder wyjściowy. Parametry można zmieniać **w trakcie
  kodowania** — zmiana w panelu Wariantu A/B natychmiast trafia do
  trwającego joba, a do pliku `.pdof.json` obok wyniku zapisywana jest
  pełna historia takich zmian (czas + parametr + wartość).
- **Presety** — wbudowane (z przykładów w Twoim README pluginu) i własne,
  zapisywane jako JSON w `~/.config/parallaxdof-gui/presets/`.
- **Podgląd** — dwa okna obok siebie lub jedno nad drugim (przycisk w
  pasku tytułu), każde pokazuje Oryginał / Wariant A / Wariant B wg
  wyboru w rozwijanych listach. Transport: play/pauza, klatka w przód/
  wstecz, pętla, wyciszenie, prędkość 0.25×–2×. Zakres testu (OD/DO)
  ustawiany ręcznie lub przyciskiem „⟵ pozycja”.
- **Wynik** — po zakończeniu kodowania (jeśli zaznaczone) otwiera się
  osobne, pełnoekranowe okno z zakodowanymi plikami obok siebie,
  podpisami (nazwa presetu/wariantu), możliwością zaznaczenia zakresu
  powtarzania (IN/OUT) i pętlą. Esc / spacja / strzałki działają jako
  skróty klawiszowe.

## Znane ograniczenia

- **Parametry pluginu bez preanalizy**: `depth-bands`, `near-gain`,
  `far-gain`, `band-blur`, `wiggle-amount`, `wiggle-freq-hz` wymagają
  `depth-file`; `motion-saliency-weight/gamma` wymagają `motion-file`.
  Bez tych danych suwaki są wyszarzone — to nie błąd GUI, tylko
  odzwierciedlenie tego, co robi sam plugin (sprawdzone w kodzie
  `gstparallaxdof.cpp`).
- **Korekta parametrów w locie** zmienia zwykłe właściwości GObject
  pluginu z wątku głównego GTK, podczas gdy plugin czyta je z wątku
  strumieniującego GStreamera — plugin nie ma wokół tego blokad (sam w
  sobie tak był napisany). W praktyce na x86_64/ARM64 to nieszkodliwe
  (odczyty/zapisy pojedynczych `int`/`double` są w praktyce atomowe), ale
  warto o tym wiedzieć.
- **`depth-file`/`motion-file`** w pluginie są czytane ściśle sekwencyjnie
  (bez seekowania), więc GUI podaje je przez potok nazwany (FIFO) od
  właściwego offsetu w pliku cache przy każdym (re)starcie podglądu/joba —
  stąd każda zmiana zakresu lub pętla w trybie głębi/ruchu wiąże się z
  krótkim przebudowaniem potoku (widoczne jako chwilowe „ładowanie”).
- GUI było testowane pod Xvfb/Wayland headless w środowisku bez GPU
  (software rendering) — na Twoim desktopie z normalną kartą graficzną
  powinno działać co najmniej tak samo dobrze.

## Struktura kodu

```
pdofgui/
├── app.py          — punkt wejścia (Gtk.Application) + obejście błędu
│                      inicjalizacji GTK/GStreamer (patrz komentarz w pliku)
├── mainwindow.py    — główne okno + okno pełnoekranowego podglądu wyników
├── widgets.py       — ParamRow/ParamPanel/TimecodeEntry
├── params.py        — introspekcja właściwości pluginu, metadane/opisy PL
├── presets.py       — presety wbudowane/użytkownika, ustawienia aplikacji
├── media.py         — sondowanie plików wideo (GstPbutils.Discoverer)
├── analysis.py       — cache preanalizy (głębia/ruch) na dysku
├── feeder.py         — podajnik plików .raw do pluginu przez FIFO
├── front.py          — wspólny front-end dekodera (uridecodebin) + seek
├── jobs.py           — zadania potokowe: preanaliza i kodowanie
├── preview.py        — silnik podglądu na żywo (tee → 2 widoki)
├── simpleplayer.py   — lekki odtwarzacz gotowych plików (okno wyniku)
├── videosurface.py   — appsink → Gtk.Picture (bez zależności od
│                        gtk4paintablesink, którego nie ma w standardowych
│                        repozytoriach — tylko jako źródło Rust)
└── gsthelpers.py      — drobne narzędzia wspólne
```
