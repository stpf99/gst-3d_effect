"""SimplePlayer — lekki odtwarzacz gotowego pliku (bez parallaxdof): decode → appsink.
Używany w pełnoekranowym przeglądzie zakodowanych wyników. Obsługuje zakres powtarzania
(IN/OUT) niezależny od całego pliku."""
from __future__ import annotations

from .front import Front
from .gsthelpers import Gst, GLib, SECOND, frame_ns, link_pad, make
from .media import MediaInfo
from .videosurface import VideoSurface


class SimplePlayer:
    def __init__(self, info: MediaInfo, surface: VideoSurface, mute: bool = True):
        self.info, self.surface, self.mute = info, surface, mute
        self.i0, self.i1 = 0, info.frames          # zakres powtarzania (IN/OUT)
        self.loop = True
        self.rate = 1.0
        self.pipeline: Gst.Pipeline | None = None
        self.state = "stopped"
        self.on_state = None
        self.on_error = None
        self._vol = None
        self._pos = 0
        self._want_play = True
        self._tries = 0
        self._gen = 0

    @property
    def fd(self) -> int:
        return self.info.frame_dur_ns

    def mid(self, f: int) -> int:
        return frame_ns(f, self.info.fps_n, self.info.fps_d) + self.fd // 2

    def frame_at(self, pos_ns: int) -> int:
        f = (int(pos_ns) * self.info.fps_n) // (SECOND * self.info.fps_d)
        return min(max(f, 0), self.info.frames - 1)

    def _set_state(self, st):
        if st != self.state:
            self.state = st
            if self.on_state:
                self.on_state(st)

    def launch(self, pos_ns: int | None = None, play: bool = True):
        self.teardown(keep_state=True)
        f = self.frame_at(self.mid(self.i0) if pos_ns is None else pos_ns)
        self._pos, self._want_play, self._tries = self.mid(f), play, 0
        self._gen += 1
        gen = self._gen
        self._set_state("loading")
        try:
            pl = self.pipeline = Gst.Pipeline.new("player")
            q0 = make("queue", max_size_buffers=4, max_size_bytes=0, max_size_time=0)
            conv = make("videoconvert")
            caps = make("capsfilter", caps=Gst.Caps.from_string("video/x-raw,format=BGR"))
            pl.add(q0); pl.add(conv); pl.add(caps)
            q0.link(conv); conv.link(caps)
            sink = self.surface.make_sink()
            pl.add(sink)
            caps.link(sink)
            self.front = Front(pl, self.info.uri, lambda pad: link_pad(pad, q0),
                               self._on_audio, lambda: self._ready(gen))
            bus = pl.get_bus()
            bus.add_signal_watch()
            self._bus_id = bus.connect("message", self._on_bus, gen)
            if pl.set_state(Gst.State.PAUSED) == Gst.StateChangeReturn.FAILURE:
                raise RuntimeError("Nie można otworzyć pliku wynikowego.")
        except Exception as e:  # noqa: BLE001
            self._fail(str(e))

    def _on_audio(self, pad):
        from .preview import _audio_sink_available
        pl = self.pipeline
        q = make("queue", max_size_buffers=0, max_size_bytes=0, max_size_time=3 * SECOND)
        conv = make("audioconvert"); res = make("audioresample")
        vol = make("volume", mute=self.mute)
        sink = make("autoaudiosink") if _audio_sink_available() else make("fakesink", sync=True)
        chain = [q, conv, res, vol, sink]
        for e in chain:
            pl.add(e)
        for a, b in zip(chain, chain[1:]):
            a.link(b)
        for e in chain:
            e.sync_state_with_parent()
        link_pad(pad, q)
        self._vol = vol

    def set_mute(self, mute):
        self.mute = mute
        if self._vol is not None:
            self._vol.set_property("mute", mute)

    def _ready(self, gen):
        if gen != self._gen or self.pipeline is None:
            return
        if not self._do_seek(self._pos):
            self._tries += 1
            if self._tries > 40:
                return self._fail("Seek nie powiódł się.")
            GLib.timeout_add(50, lambda: (self._ready(gen), False)[1])
            return
        if self._want_play:
            self.pipeline.set_state(Gst.State.PLAYING)
            self._set_state("playing")
        else:
            self._set_state("paused")

    def _do_seek(self, pos_ns) -> bool:
        if self.pipeline is None:
            return False
        stop = self.mid(self.i1 - 1) if self.i1 < self.info.frames else None
        flags = Gst.SeekFlags.FLUSH | Gst.SeekFlags.ACCURATE | Gst.SeekFlags.SEGMENT
        return self.pipeline.seek(self.rate, Gst.Format.TIME, flags,
                                  Gst.SeekType.SET, int(pos_ns),
                                  Gst.SeekType.SET if stop is not None else Gst.SeekType.NONE,
                                  int(stop) if stop is not None else -1)

    def _on_bus(self, _bus, msg, gen):
        if gen != self._gen:
            return
        t = msg.type
        if t == Gst.MessageType.ERROR:
            err, dbg = msg.parse_error()
            self._fail(f"{err.message}\n{dbg or ''}".strip())
        elif t in (Gst.MessageType.SEGMENT_DONE, Gst.MessageType.EOS):
            if self.loop:
                self._do_seek(self.mid(self.i0))
            else:
                self.pipeline.set_state(Gst.State.PAUSED)
                self._set_state("ended")

    def _fail(self, msg):
        self.teardown()
        if self.on_error:
            self.on_error(msg)

    def play(self):
        if self.state in ("stopped", "ended"):
            self.launch(None, True)
        elif self.state == "paused" and self.pipeline:
            self.pipeline.set_state(Gst.State.PLAYING)
            self._set_state("playing")

    def pause(self):
        if self.state == "playing" and self.pipeline:
            self.pipeline.set_state(Gst.State.PAUSED)
            self._set_state("paused")

    def toggle(self):
        self.pause() if self.state == "playing" else self.play()

    def seek(self, pos_ns):
        f = self.frame_at(pos_ns)
        pos = self.mid(f)
        if self.pipeline is None or self.state in ("stopped", "ended"):
            self.launch(pos, self.state == "playing")
        else:
            self._pos = pos
            self._do_seek(pos)

    def step(self, frames):
        self.seek(self.position_ns() + frames * self.fd)

    def position_ns(self) -> int:
        if self.pipeline is not None and self.state in ("playing", "paused", "ended"):
            ok, pos = self.pipeline.query_position(Gst.Format.TIME)
            if ok:
                return int(pos)
        return self._pos

    def set_in(self, frame: int):
        self.i0 = max(0, min(frame, self.i1 - 1))

    def set_out(self, frame: int):
        self.i1 = min(self.info.frames, max(frame, self.i0 + 1))

    def teardown(self, keep_state=False):
        self._gen += 1
        if self.pipeline is not None:
            try:
                bus = self.pipeline.get_bus()
                bus.disconnect(self._bus_id)
                bus.remove_signal_watch()
            except Exception:  # noqa: BLE001
                pass
            self.pipeline.set_state(Gst.State.NULL)
            self.pipeline = None
        if not keep_state:
            self._set_state("stopped")
