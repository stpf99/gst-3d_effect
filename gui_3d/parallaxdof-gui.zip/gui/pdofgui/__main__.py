"""Uruchomienie: python3 -m pdofgui  (z katalogu nadrzędnego względem pdofgui/)."""
from .app import main

if __name__ == "__main__":
    main()
