"""VideoSurface — appsink + Gtk.Picture. Portabilne (nie wymaga gtk4paintablesink,
którego nie ma w standardowych repo — tylko jako źródło Rust). Klatki BGR trafiają
z wątku strumieniującego do Gdk.MemoryTexture przez GLib.idle_add.

Podgląd jest skalowany do PREVIEW_MAX_W, żeby duże materiały (4K) nie zamulały UI —
encodowanie zawsze pracuje na pełnej rozdzielczości źródła (osobna gałąź potoku)."""
from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GLib, Gst, GObject  # noqa: E402

from .gsthelpers import make

PREVIEW_MAX_W = 960


class VideoSurface(Gtk.Overlay):
    """Gtk.Picture na czarnym tle + etykieta (podpis) nakładana w rogu."""

    def __init__(self, caption: str = ""):
        super().__init__()
        self.picture = Gtk.Picture(content_fit=Gtk.ContentFit.CONTAIN,
                                   can_shrink=True, hexpand=True, vexpand=True)
        self.picture.add_css_class("pdof-video")
        self.add_overlay(self.picture) if False else None
        self.set_child(self.picture)
        self.label = Gtk.Label(label=caption, halign=Gtk.Align.START, valign=Gtk.Align.START,
                               margin_start=8, margin_top=6, visible=bool(caption))
        self.label.add_css_class("pdof-caption")
        self.add_overlay(self.label)
        self._appsink = None
        self._last_ratio = None

    def set_caption(self, text: str):
        self.label.set_label(text)
        self.label.set_visible(bool(text))

    def clear(self):
        self.picture.set_paintable(None)

    def make_sink(self) -> Gst.Element:
        """Zwraca element(y) GStreamera do wpięcia jako ostatni w gałęzi potoku."""
        scale = make("videoscale")
        rate_caps = make(
            "capsfilter",
            caps=Gst.Caps.from_string(f"video/x-raw,format=BGR,width=[1,{PREVIEW_MAX_W}]"))
        sink = make("appsink", emit_signals=True, sync=True, max_buffers=2, drop=True)
        sink.connect("new-sample", self._on_sample)
        bin_ = Gst.Bin.new(None)
        for e in (scale, rate_caps, sink):
            bin_.add(e)
        scale.link(rate_caps)
        rate_caps.link(sink)
        bin_.add_pad(Gst.GhostPad.new("sink", scale.get_static_pad("sink")))
        self._appsink = sink
        return bin_

    def _on_sample(self, sink):
        sample = sink.emit("pull-sample")
        if sample is None:
            return Gst.FlowReturn.OK
        buf = sample.get_buffer()
        caps = sample.get_caps()
        s = caps.get_structure(0)
        w, h = s.get_value("width"), s.get_value("height")
        ok, mapinfo = buf.map(Gst.MapFlags.READ)
        if not ok:
            return Gst.FlowReturn.OK
        try:
            data = bytes(mapinfo.data)
        finally:
            buf.unmap(mapinfo)
        GLib.idle_add(self._update, data, w, h)
        return Gst.FlowReturn.OK

    def _update(self, data: bytes, w: int, h: int):
        stride = w * 3
        if len(data) < stride * h:
            return False
        gbytes = GLib.Bytes.new(data)
        tex = Gdk.MemoryTexture.new(w, h, Gdk.MemoryFormat.B8G8R8, gbytes, stride)
        self.picture.set_paintable(tex)
        return False
