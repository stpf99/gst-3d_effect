"""PreviewEngine — jedno źródło → tee → do 2 widoków (oryginał / efekt A / efekt B).

Parametry zmieniane W LOCIE (set_param) trafiają do wszystkich instancji parallaxdof danego
slotu. Ograniczenia pluginu (zweryfikowane w kodzie) obsługuje tak:
  • depth-file/motion-file czytane sekwencyjnie → RawFeeder (FIFO od klatki startu), a każdy
    seek/pętla przy użyciu plików = nowy potok (launch);
  • do pierwszego seeka bufory są blokowane na bramce, żeby preroll klatki 0 nie „zjadł” klatki map.
"""
from __future__ import annotations

from .analysis import DataFiles
from .feeder import RawFeeder
from .front import Front
from .gsthelpers import (Gst, GLib, SECOND, add_link, block_buffers, frame_ns, have, link_pad,
                         make, req_pad, set_prop)
from .media import MediaInfo

_AUDIO_OK = None


def _audio_sink_available() -> bool:
    """Sonda raz na proces: czy autoaudiosink da się użyć (urządzenie audio obecne)?
    W środowisku bez audio (CI/headless) po cichu spadamy na fakesink(sync=True) —
    to jedyny cel True/False tej flagi: NIE wpływa na synchronizację/pacing."""
    global _AUDIO_OK
    if _AUDIO_OK is not None:
        return _AUDIO_OK
    _AUDIO_OK = False
    if have("autoaudiosink"):
        el = make("autoaudiosink")
        if el.set_state(Gst.State.READY) == Gst.StateChangeReturn.SUCCESS:
            _AUDIO_OK = True
        el.set_state(Gst.State.NULL)
    return _AUDIO_OK


class PreviewEngine:
    def __init__(self, info: MediaInfo, surfaces: list):
        self.info, self.surfaces = info, surfaces
        self.views = ["orig", "A"]
        self.params = {"A": {}, "B": {}}
        self.data_mode = "realtime"            # realtime | depth | depth+motion | motion
        self.data: DataFiles | None = None
        self.i0, self.i1 = 0, info.frames      # zakres [i0, i1)
        self.loop = False
        self.rate = 1.0
        self.mute = True
        self.pipeline: Gst.Pipeline | None = None
        self.pdofs: list[tuple[str, Gst.Element]] = []
        self.feeders: list[RawFeeder] = []
        self._blocks: list[tuple[Gst.Pad, int]] = []
        self.state = "stopped"                 # stopped | loading | paused | playing | ended
        self.on_state = None                   # fn(state)
        self.on_error = None                   # fn(msg)
        self._want_play = True
        self._pos = 0
        self._tries = 0
        self._gen = 0                          # generacja potoku — odrzuca spóźnione callbacki
        self.sink_probe = None                 # (test) fn(view_index, sink_bin)

    # ── zakres / pozycje ─────────────────────────────────────────────────────
    @property
    def fd(self) -> int:
        return self.info.frame_dur_ns

    def frame_at(self, pos_ns: int) -> int:
        f = (int(pos_ns) * self.info.fps_n) // (SECOND * self.info.fps_d)
        return min(max(f, self.i0), self.i1 - 1)

    def mid(self, f: int) -> int:
        return frame_ns(f, self.info.fps_n, self.info.fps_d) + self.fd // 2

    @property
    def range_start_ns(self) -> int:
        return self.mid(self.i0)

    @property
    def range_stop_ns(self) -> int | None:
        return self.mid(self.i1 - 1) if self.i1 < self.info.frames else None

    @property
    def uses_files(self) -> bool:
        return (self.data_mode != "realtime" and self.data is not None
                and any(v in ("A", "B") for v in self.views))

    def _set_state(self, st: str):
        if st != self.state:
            self.state = st
            if self.on_state:
                self.on_state(st)

    # ── budowa potoku ────────────────────────────────────────────────────────
    def _data_props(self, f0: int) -> dict:
        props, df, dm = {}, self.data, self.data_mode
        if dm == "realtime" or df is None:
            return props
        off = f0 - df.first_frame
        if off < 0 or f0 >= df.first_frame + df.frames:
            raise RuntimeError("Pozycja poza zakresem preanalizy — uruchom analizę tego zakresu.")
        if dm in ("depth", "depth+motion"):
            fe = RawFeeder(df.depth_path, off * df.depth_frame_bytes)
            self.feeders.append(fe)
            props["depth-file"] = fe.path
        if dm in ("motion", "depth+motion") and df.motion_path:
            fe = RawFeeder(df.motion_path, off * df.motion_frame_bytes)
            self.feeders.append(fe)
            props["motion-file"] = fe.path
            props["motion-max-mag"] = df.motion_max_mag
        return props

    def launch(self, pos_ns: int | None = None, play: bool = True):
        """(Re)buduje potok i startuje od pos_ns (domyślnie: początek zakresu)."""
        self.teardown(keep_state=True)
        f = self.frame_at(self.range_start_ns if pos_ns is None else pos_ns)
        self._pos, self._want_play, self._tries = self.mid(f), play, 0
        self._gen += 1
        gen = self._gen
        self._set_state("loading")
        try:
            pl = self.pipeline = Gst.Pipeline.new("preview")
            q0 = make("queue", max_size_buffers=4, max_size_bytes=0, max_size_time=0)
            conv = make("videoconvert")
            caps = make("capsfilter", caps=Gst.Caps.from_string("video/x-raw,format=BGR"))
            tee = make("tee")
            add_link(pl, q0, conv, caps, tee)
            gate = caps.get_static_pad("src")
            self._blocks.append((gate, block_buffers(gate)))
            self.pdofs = []
            for vi, src in enumerate(self.views):
                q = make("queue", max_size_buffers=2, max_size_bytes=0, max_size_time=0)
                chain = [q]
                if src in ("A", "B"):
                    pd = make("parallaxdof")
                    for k, v in {**self.params[src], **self._data_props(f)}.items():
                        set_prop(pd, k, v)
                    chain.append(pd)
                    self.pdofs.append((src, pd))
                sink = self.surfaces[vi].make_sink()
                if self.sink_probe:
                    self.sink_probe(vi, sink)
                chain.append(sink)
                add_link(pl, *chain)
                if req_pad(tee, "src_%u").link(q.get_static_pad("sink")) != Gst.PadLinkReturn.OK:
                    raise RuntimeError("tee: nie można połączyć gałęzi")
            self.front = Front(pl, self.info.uri, lambda pad: link_pad(pad, q0),
                               self._on_audio_pad, lambda: self._ready(gen))
            bus = pl.get_bus()
            bus.add_signal_watch()
            self._bus_id = bus.connect("message", self._on_bus, gen)
            if pl.set_state(Gst.State.PAUSED) == Gst.StateChangeReturn.FAILURE:
                raise RuntimeError("Nie można uruchomić podglądu (sprawdź pluginy i pliki map).")
        except Exception as e:  # noqa: BLE001
            self._fail(str(e))

    def _on_audio_pad(self, pad: Gst.Pad):
        '''Audio ZAWSZE syncowane do zegara (sync=True) — inaczej niesyncowany fakesink
        (jak w Job/Front.to_fakesink, gdzie chcemy maks. szybkości) osiąga koniec segmentu
        natychmiast i psuje śledzenie SEGMENT_DONE dla całego potoku (patrz Front.to_fakesink:
        tam sync=False jest celowe i bezpieczne, bo Job nie używa seeka z flagą SEGMENT).'''
        pl = self.pipeline
        q = make("queue", max_size_buffers=0, max_size_bytes=0, max_size_time=3 * SECOND)
        conv = make("audioconvert")
        res = make("audioresample")
        vol = make("volume", mute=self.mute)
        sink = make("autoaudiosink") if _audio_sink_available() else make("fakesink", sync=True)
        chain = [q, conv, res, vol, sink]
        for e in chain:
            pl.add(e)
        for a, b in zip(chain, chain[1:]):
            a.link(b)
        for e in chain:
            e.sync_state_with_parent()
        link_pad(pad, q)
        self._vol = vol

    def set_mute(self, mute: bool):
        self.mute = mute
        if getattr(self, "_vol", None) is not None:
            self._vol.set_property("mute", mute)

    def _ready(self, gen: int):
        if gen != self._gen or self.pipeline is None:
            return
        if not self._do_seek(self._pos):
            self._tries += 1
            if self._tries > 40:
                return self._fail("Seek na początek zakresu nie powiódł się.")
            GLib.timeout_add(50, lambda: (self._ready(gen), False)[1])
            return
        for pad, pid in self._blocks:
            pad.remove_probe(pid)
        self._blocks.clear()
        if self._want_play:
            self.pipeline.set_state(Gst.State.PLAYING)
            self._set_state("playing")
        else:
            self._set_state("paused")

    def _do_seek(self, pos_ns: int) -> bool:
        if self.pipeline is None:
            return False
        stop = self.range_stop_ns
        flags = Gst.SeekFlags.FLUSH | Gst.SeekFlags.ACCURATE | Gst.SeekFlags.SEGMENT
        return self.pipeline.seek(self.rate, Gst.Format.TIME, flags,
                                  Gst.SeekType.SET, int(pos_ns),
                                  Gst.SeekType.SET if stop is not None else Gst.SeekType.NONE,
                                  int(stop) if stop is not None else -1)

    # ── bus ──────────────────────────────────────────────────────────────────
    def _on_bus(self, _bus, msg, gen):
        if gen != self._gen:
            return
        t = msg.type
        if t == Gst.MessageType.ERROR:
            err, dbg = msg.parse_error()
            self._fail(f"{err.message}\n{dbg or ''}".strip())
        elif t in (Gst.MessageType.SEGMENT_DONE, Gst.MessageType.EOS):
            self._on_end()

    def _on_end(self):
        if self.loop:
            if self.uses_files:
                GLib.idle_add(lambda: (self.launch(None, True), False)[1])
            else:
                self._do_seek(self.range_start_ns)
        else:
            if self.pipeline:
                self.pipeline.set_state(Gst.State.PAUSED)
            self._set_state("ended")

    def _fail(self, msg: str):
        self.teardown()
        if self.on_error:
            self.on_error(msg)

    # ── sterowanie ───────────────────────────────────────────────────────────
    def play(self):
        if self.state in ("stopped", "ended"):
            self.launch(None, True)
        elif self.state == "paused" and self.pipeline:
            self.pipeline.set_state(Gst.State.PLAYING)
            self._set_state("playing")

    def pause(self):
        if self.state == "playing" and self.pipeline:
            self.pipeline.set_state(Gst.State.PAUSED)
            self._set_state("paused")

    def toggle(self):
        if self.state == "playing":
            self.pause()
        else:
            self.play()

    def stop(self):
        self.teardown()

    def seek(self, pos_ns: int):
        f = self.frame_at(pos_ns)
        pos = self.mid(f)
        if self.pipeline is None or self.state in ("stopped", "ended") or self.uses_files:
            self.launch(pos, self.state == "playing")
        else:
            self._pos = pos
            self._do_seek(pos)

    def step(self, frames: int):
        p = self.position_ns()
        self.seek(p + frames * self.fd)

    def set_rate(self, rate: float):
        self.rate = rate
        if self.pipeline is not None and self.state in ("playing", "paused"):
            self.seek(self.position_ns())

    def position_ns(self) -> int:
        if self.pipeline is not None and self.state in ("playing", "paused", "ended"):
            ok, pos = self.pipeline.query_position(Gst.Format.TIME)
            if ok:
                return int(pos)
        return self._pos

    def set_param(self, slot: str, name: str, value):
        self.params[slot][name] = value
        for s, el in self.pdofs:
            if s == slot:
                set_prop(el, name, value)

    def teardown(self, keep_state: bool = False):
        self._gen += 1
        if self.pipeline is not None:
            try:
                bus = self.pipeline.get_bus()
                bus.disconnect(self._bus_id)
                bus.remove_signal_watch()
            except Exception:  # noqa: BLE001
                pass
            self.pipeline.set_state(Gst.State.NULL)
            self.pipeline = None
        for fe in self.feeders:
            fe.close()
        self.feeders.clear()
        self._blocks.clear()
        self.pdofs = []
        if not keep_state:
            self._set_state("stopped")
