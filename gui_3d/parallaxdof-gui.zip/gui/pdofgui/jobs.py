"""Joby na potoku GStreamera: preanaliza (depthanalyzer) i encodowanie (parallaxdof → enkoder)."""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, asdict, field
from pathlib import Path

from .analysis import AnalysisCache, AnalysisMeta, DataFiles, canon_params, params_key
from .feeder import RawFeeder
from .front import Front, seek_via_pad
from .gsthelpers import (Gst, GLib, SECOND, add_link, block_buffers, frame_ns, have, link_pad,
                         make, req_pad, set_prop)
from .media import MediaInfo


class Job:
    """Baza: decode → [blokada] → podklasa. Po no-more-pads: seek na zakres, zwolnienie blokady."""
    kind = "job"

    def __init__(self, info: MediaInfo, i0: int, i1: int, on_progress=None, on_done=None):
        self.info = info
        self.i0, self.i1 = i0, i1
        fd = info.frame_dur_ns
        self.start_ns = frame_ns(i0, info.fps_n, info.fps_d) + fd // 2
        # stop w połowie ostatniej klatki zakresu → klatka i1 już nie wchodzi
        self.stop_ns = (frame_ns(i1 - 1, info.fps_n, info.fps_d) + fd // 2) if i1 < info.frames else None
        self.on_progress, self.on_done = on_progress, on_done
        self.pipeline: Gst.Pipeline | None = None
        self.feeders: list[RawFeeder] = []
        self._blocks: list[tuple[Gst.Pad, int]] = []
        self.gate_pad: Gst.Pad | None = None
        self.finished = False
        self._eos_requested = False
        self._seek_tries = 0
        self._t0 = 0.0
        self.error: str | None = None
        self.cancelled = False

    # ── do nadpisania ────────────────────────────────────────────────────────
    def build(self) -> Gst.Element:
        """Buduje gałąź wideo; zwraca element wejściowy (queue). Ustaw self.gate_pad."""
        raise NotImplementedError

    def on_audio(self, pad: Gst.Pad):
        self.front.to_fakesink(pad)

    def finalize(self, ok: bool):
        pass

    # ── cykl życia ───────────────────────────────────────────────────────────
    def start(self):
        self.pipeline = Gst.Pipeline.new(self.kind)
        self._t0 = time.monotonic()
        try:
            self.vin = self.build()
            self.front = Front(self.pipeline, self.info.uri,
                               lambda pad: link_pad(pad, self.vin), self.on_audio, self._go)
            bus = self.pipeline.get_bus()
            bus.add_signal_watch()
            self._bus_id = bus.connect("message", self._on_bus)
            if self.pipeline.set_state(Gst.State.PAUSED) == Gst.StateChangeReturn.FAILURE:
                raise RuntimeError("Nie można uruchomić potoku (sprawdź pliki i pluginy).")
        except Exception as e:  # noqa: BLE001
            self._finish(False, str(e))
            return
        self._tick_id = GLib.timeout_add(250, self._tick)

    def _go(self):
        if self.finished:
            return
        ok = seek_via_pad(self.gate_pad, self.start_ns, self.stop_ns)
        if not ok:
            self._seek_tries += 1
            if self._seek_tries > 40:
                self._finish(False, "Seek na początek zakresu nie powiódł się.")
            else:
                GLib.timeout_add(50, lambda: (self._go(), False)[1])
            return
        for pad, pid in self._blocks:
            pad.remove_probe(pid)
        self._blocks.clear()
        self.pipeline.set_state(Gst.State.PLAYING)

    def _on_bus(self, _bus, msg):
        t = msg.type
        if t == Gst.MessageType.EOS:
            self._finish(True)
        elif t == Gst.MessageType.ERROR:
            err, dbg = msg.parse_error()
            self._finish(False, f"{err.message}\n{dbg or ''}".strip())

    def progress(self) -> float | None:
        if not self.pipeline:
            return None
        ok, pos = self.pipeline.query_position(Gst.Format.TIME)
        if not ok:
            return None
        end = self.stop_ns if self.stop_ns is not None else int(self.info.duration * SECOND)
        span = max(1, end - self.start_ns)
        return min(1.0, max(0.0, (pos - self.start_ns) / span))

    def _tick(self):
        if self.finished:
            return False
        p = self.progress()
        if p is not None and self.on_progress:
            el = time.monotonic() - self._t0
            frames = p * (self.i1 - self.i0)
            fps = frames / el if el > 0.5 else 0.0
            eta = (1 - p) * el / p if p > 0.02 else None
            self.on_progress(p, fps, eta)
        return True

    def _finish(self, ok: bool, msg: str | None = None):
        if self.finished:
            return
        self.finished = True
        self.error = None if ok else msg
        if self.pipeline:
            bus = self.pipeline.get_bus()
            try:
                bus.disconnect(self._bus_id)
                bus.remove_signal_watch()
            except Exception:  # noqa: BLE001
                pass
            self.pipeline.set_state(Gst.State.NULL)
        for f in self.feeders:
            f.close()
        self.feeders.clear()
        try:
            self.finalize(ok)
        except Exception as e:  # noqa: BLE001
            ok, self.error = False, f"Finalizacja: {e}"
        if self.on_done:
            self.on_done(self, ok, self.error)

    def cancel(self):
        self.cancelled = True
        self._finish(False, "Anulowano.")

    def stop_and_save(self):
        """Kończy elegancko (EOS przez potok) — plik wyjściowy zostaje poprawnie zamknięty."""
        if self.finished or self._eos_requested:
            return
        self._eos_requested = True
        for pad, pid in self._blocks:
            pad.remove_probe(pid)
        self._blocks.clear()
        self.pipeline.send_event(Gst.Event.new_eos())


# ═════════════════════════════════════ ANALIZA ════════════════════════════════
class AnalysisJob(Job):
    kind = "analysis"

    def __init__(self, info, i0, i1, an_params: dict, motion: bool, max_mag: float,
                 cache: AnalysisCache, on_progress=None, on_done=None):
        super().__init__(info, i0, i1, on_progress, on_done)
        self.an_params, self.motion, self.max_mag, self.cache = an_params, motion, max_mag, cache
        self.base = cache.base_for(info, an_params, motion, max_mag, i0, i1)
        self.depth_path = str(self.base) + ".depth.raw"
        self.motion_path = str(self.base) + ".motion.raw" if motion else None
        self.meta: AnalysisMeta | None = None

    def build(self):
        pl = self.pipeline
        q = make("queue", max_size_buffers=6, max_size_bytes=0, max_size_time=0)
        conv = make("videoconvert")
        caps = make("capsfilter", caps=Gst.Caps.from_string("video/x-raw,format=BGR"))
        an = make("depthanalyzer", location=self.depth_path)
        for k, v in canon_params(self.an_params).items():
            set_prop(an, k, v)
        if self.motion_path:
            set_prop(an, "motion-file", self.motion_path)
            set_prop(an, "motion-max-mag", self.max_mag)
        fk = make("fakesink", sync=False, async_=False)
        add_link(pl, q, conv, caps, an, fk)
        gate = self.gate_pad = caps.get_static_pad("src")
        self._blocks.append((gate, block_buffers(gate)))
        return q

    def finalize(self, ok):
        wh = self.info.width * self.info.height
        if ok:
            frames = os.path.getsize(self.depth_path) // wh
            if self.motion_path:
                frames = min(frames, os.path.getsize(self.motion_path) // (wh * 2))
            if frames <= 0:
                raise RuntimeError("Analiza nie zapisała żadnej klatki.")
            self.meta = self.cache.register(AnalysisMeta(
                vsig=self.info.vsig, video=self.info.path, width=self.info.width,
                height=self.info.height, fps_n=self.info.fps_n, fps_d=self.info.fps_d,
                first_frame=self.i0, frames=frames, depth=self.depth_path, motion=self.motion_path,
                motion_max_mag=self.max_mag, analyzer=canon_params(self.an_params),
                pkey=params_key(self.an_params)), self.base)
        else:
            for p in (self.depth_path, self.motion_path):
                if p and os.path.exists(p):
                    os.remove(p)


# ═════════════════════════════════════ ENKODOWANIE ════════════════════════════
@dataclass
class EncSettings:
    codec: str = "x264"          # x264 | x265 | vp9 | custom
    container: str = "mp4"       # mp4 | mkv | webm
    rc: str = "quality"          # quality | bitrate
    quality: int = 20
    bitrate: int = 8000          # kbps
    speed: str = "medium"        # fast | medium | slow
    audio: str = "aac"           # aac | opus | vorbis | none
    audio_kbps: int = 192
    custom: str = ""             # np. "vah264enc bitrate=8000 ! h264parse"

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        return cls(**{k: v for k, v in (d or {}).items() if k in cls.__dataclass_fields__})


CODECS = {
    # klucz: (etykieta, fabryka, parser, kontenery, zakres jakości (min,max,domyślna))
    "x264": ("H.264 (x264enc)", "x264enc", "h264parse", ("mp4", "mkv"), (0, 51, 20)),
    "x265": ("H.265 (x265enc)", "x265enc", "h265parse", ("mp4", "mkv"), (0, 51, 24)),
    "vp9":  ("VP9 (vp9enc)",    "vp9enc",  None,        ("webm", "mkv"), (0, 63, 30)),
    "custom": ("Własny fragment pipeline…", None, None, ("mp4", "mkv", "webm"), (0, 63, 20)),
}
SPEED = {"x264": {"fast": "veryfast", "medium": "medium", "slow": "slow"},
         "x265": {"fast": "veryfast", "medium": "medium", "slow": "slow"},
         "vp9": {"fast": 6, "medium": 4, "slow": 2}}
CONTAINERS = {"mp4": ("MP4", "mp4mux"), "mkv": ("Matroska (MKV)", "matroskamux"), "webm": ("WebM", "webmmux")}
AUDIO = {"aac": ("AAC", ("avenc_aac", "voaacenc", "fdkaacenc", "faac"), "aacparse", ("mp4", "mkv")),
         "opus": ("Opus", ("opusenc",), None, ("mkv", "webm")),
         "vorbis": ("Vorbis", ("vorbisenc",), None, ("mkv", "webm")),
         "none": ("Bez dźwięku", (), None, ("mp4", "mkv", "webm"))}


def available_codecs() -> list[str]:
    out = [k for k, v in CODECS.items() if k != "custom" and have(v[1])]
    if "x264" in out or out:
        out.append("custom")
    return out


def available_containers() -> list[str]:
    return [k for k, v in CONTAINERS.items() if have(v[1])]


def audio_factory(kind: str) -> str | None:
    for f in AUDIO[kind][1]:
        if have(f):
            return f
    return None


def build_video_encoder(es: EncSettings) -> list[Gst.Element]:
    if es.codec == "custom":
        b = Gst.parse_bin_from_description(es.custom.strip(), True)
        return [b]
    label, fac, parse, _cont, _q = CODECS[es.codec]
    enc = make(fac)
    speed = SPEED[es.codec][es.speed]
    if es.codec == "x264":
        if es.rc == "quality":
            set_prop(enc, "pass", "qual")
            set_prop(enc, "quantizer", es.quality)
        else:
            set_prop(enc, "bitrate", es.bitrate)
        set_prop(enc, "speed-preset", speed)
    elif es.codec == "x265":
        if es.rc == "quality":
            set_prop(enc, "option-string", f"crf={es.quality}")
        else:
            set_prop(enc, "bitrate", es.bitrate)
        set_prop(enc, "speed-preset", speed)
    elif es.codec == "vp9":
        if es.rc == "quality":
            set_prop(enc, "end-usage", "cq")
            set_prop(enc, "cq-level", es.quality)
            set_prop(enc, "target-bitrate", 30_000_000)
        else:
            set_prop(enc, "end-usage", "vbr")
            set_prop(enc, "target-bitrate", es.bitrate * 1000)
        set_prop(enc, "cpu-used", speed)
        set_prop(enc, "threads", max(1, (os.cpu_count() or 4) // 2))
        set_prop(enc, "row-mt", True)
    els = [enc]
    if parse:
        els.append(make(parse))
    return els


class EncodeJob(Job):
    kind = "encode"

    def __init__(self, info, i0, i1, target: str, params: dict | None, data_mode: str,
                 data: DataFiles | None, es: EncSettings, out_path: str,
                 on_progress=None, on_done=None, meta_extra: dict | None = None):
        super().__init__(info, i0, i1, on_progress, on_done)
        self.target = target                 # 'A' | 'B' | 'O' (oryginał, bez efektu)
        self.params = dict(params or {})
        self.data_mode, self.data, self.es, self.out_path = data_mode, data, es, out_path
        self.meta_extra = meta_extra or {}
        self.pdof: Gst.Element | None = None
        self.changes: list[dict] = []
        self._mux = None
        self._audio_linked = False

    def _data_props(self) -> dict:
        props = {}
        dm, df = self.data_mode, self.data
        if self.target == "O" or dm == "realtime" or df is None:
            return props
        off = self.i0 - df.first_frame
        if off < 0:
            raise RuntimeError("Zakres zaczyna się przed początkiem preanalizy.")
        if dm in ("depth", "depth+motion"):
            f = RawFeeder(df.depth_path, off * df.depth_frame_bytes)
            self.feeders.append(f)
            props["depth-file"] = f.path
        if dm in ("motion", "depth+motion") and df.motion_path:
            f = RawFeeder(df.motion_path, off * df.motion_frame_bytes)
            self.feeders.append(f)
            props["motion-file"] = f.path
            props["motion-max-mag"] = df.motion_max_mag
        return props

    def build(self):
        pl, es = self.pipeline, self.es
        Path(self.out_path).parent.mkdir(parents=True, exist_ok=True)
        q = make("queue", max_size_buffers=6, max_size_bytes=0, max_size_time=0)
        conv = make("videoconvert")
        caps = make("capsfilter", caps=Gst.Caps.from_string("video/x-raw,format=BGR"))
        chain = [q, conv, caps]
        if self.target != "O":
            self.pdof = make("parallaxdof")
            for k, v in {**self.params, **self._data_props()}.items():
                set_prop(self.pdof, k, v)
            chain.append(self.pdof)
        chain.append(make("videoconvert"))
        chain += build_video_encoder(es)
        chain.append(make("queue", max_size_buffers=8, max_size_bytes=0, max_size_time=0))
        add_link(pl, *chain)
        gate = self.gate_pad = caps.get_static_pad("src")
        self._blocks.append((gate, block_buffers(gate)))
        mux = make(CONTAINERS[es.container][1])
        set_prop(mux, "faststart", True)
        sink = make("filesink", location=self.out_path)
        add_link(pl, mux, sink)
        self._mux = mux
        if not chain[-1].link_pads("src", mux, "video_%u"):
            vp = req_pad(mux, "video_%u")
            if chain[-1].get_static_pad("src").link(vp) != Gst.PadLinkReturn.OK:
                raise RuntimeError("Enkoder wideo nie łączy się z wybranym kontenerem.")
        return q

    def on_audio(self, pad):
        es = self.es
        fac = audio_factory(es.audio) if es.audio != "none" else None
        if not fac or self._audio_linked:
            return self.front.to_fakesink(pad)
        self._audio_linked = True
        _l, _f, parse, _c = AUDIO[es.audio]
        chain = [make("queue", max_size_buffers=0, max_size_bytes=0, max_size_time=3 * SECOND),
                 make("audioconvert"), make("audioresample"), make(fac)]
        set_prop(chain[-1], "bitrate", es.audio_kbps * 1000)
        if parse:
            chain.append(make(parse))
        chain.append(make("queue", max_size_buffers=0, max_size_bytes=0, max_size_time=3 * SECOND))
        for e in chain:
            self.pipeline.add(e)
        for a, b in zip(chain, chain[1:]):
            a.link(b)
        ap = req_pad(self._mux, "audio_%u")
        chain[-1].get_static_pad("src").link(ap)
        for e in chain:
            e.sync_state_with_parent()
        link_pad(pad, chain[0])

    def set_param(self, name: str, value):
        """Korekta w locie w trakcie encodowania (tylko parametry bezpieczne live)."""
        self.params[name] = value
        if self.pdof is not None:
            set_prop(self.pdof, name, value)
            ok, pos = self.pipeline.query_position(Gst.Format.TIME) if self.pipeline else (False, 0)
            self.changes.append({"t": round(pos / SECOND, 3) if ok else None, "param": name, "value": value})

    def finalize(self, ok):
        if not ok:
            if not self.cancelled and self._eos_requested:
                return
            try:
                os.remove(self.out_path)
            except OSError:
                pass
            return
        side = {
            "app": "parallaxdof-gui", "source": self.info.path, "output": self.out_path,
            "target": self.target, "frames": [self.i0, self.i1],
            "range_s": [round(self.info.frame_to_t(self.i0), 3), round(self.info.frame_to_t(self.i1), 3)],
            "params": self.params, "live_changes": self.changes, "data_mode": self.data_mode,
            "analysis": (self.data.__dict__ if self.data else None), "encoder": self.es.to_dict(),
            **self.meta_extra,
        }
        try:
            Path(self.out_path + ".pdof.json").write_text(
                json.dumps(side, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        except OSError:
            pass
