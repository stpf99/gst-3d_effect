"""Wspólne widżety UI: wiersz parametru (suwak+spin+reset), panel parametrów per slot,
pole timecode, pasek transportu."""
from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib, GObject, Pango  # noqa: E402

from . import params as P
from .gsthelpers import fmt_tc, parse_tc


class ParamRow(Gtk.Box):
    """Suwak + spinner + przycisk resetu dla jednej właściwości pluginu."""

    __gsignals__ = {"changed": (GObject.SignalFlags.RUN_FIRST, None, (str, float))}

    def __init__(self, name: str, spec: P.PSpec, label: str, blurb: str, value):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.name, self.spec, self.default = name, spec, value
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        lab = Gtk.Label(label=label, xalign=0, hexpand=True,
                        ellipsize=Pango.EllipsizeMode.END, max_width_chars=1)
        lab.set_tooltip_text(blurb)
        head.append(lab)
        self.spin = Gtk.SpinButton()
        self.spin.set_range(spec.minimum, spec.maximum)
        self.spin.set_increments(spec.step, spec.step * 5)
        self.spin.set_digits(spec.digits)
        self.spin.set_value(value)
        self.spin.set_width_chars(6)
        head.append(self.spin)
        reset = Gtk.Button(icon_name="edit-undo-symbolic", tooltip_text="Przywróć domyślną")
        reset.add_css_class("flat")
        reset.connect("clicked", lambda *_: self.set_value(spec.default, emit=True))
        head.append(reset)
        self.append(head)
        self.scale = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL,
                               adjustment=self.spin.get_adjustment(), digits=spec.digits,
                               draw_value=False, hexpand=True)
        self.scale.set_range(spec.minimum, spec.maximum)
        self.append(self.scale)
        self._emitting = False
        self.spin.connect("value-changed", self._on_change)

    def _on_change(self, *_a):
        if self._emitting:
            return
        self.emit("changed", self.name, self.spin.get_value())

    def set_value(self, v, emit: bool = False):
        self._emitting = not emit
        self.spin.set_value(v)
        self._emitting = False

    def get_value(self) -> float:
        return self.spin.get_value()


class ParamPanel(Gtk.Box):
    """Akordeon grup parametrów parallaxdof dla jednego slotu (A/B). Emit 'param-changed'."""

    __gsignals__ = {"param-changed": (GObject.SignalFlags.RUN_FIRST, None, (str, float))}

    def __init__(self, specs: dict[str, P.PSpec]):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.rows: dict[str, ParamRow] = {}
        editable = P.editable(specs)
        by_group: dict[str, list[str]] = {}
        for name in editable:
            grp = P.PDOF_META.get(name, ("other",))[0]
            by_group.setdefault(grp, []).append(name)
        for gkey, gtitle in P.GROUPS:
            names = by_group.get(gkey)
            if not names:
                continue
            exp = Gtk.Expander(label=gtitle)
            exp.set_expanded(gkey in ("main", "bands"))
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                          margin_start=10, margin_top=6, margin_bottom=6)
            for name in names:
                spec = editable[name]
                meta = P.PDOF_META.get(name)
                label = meta[1] if meta else name
                blurb = meta[2] if meta else spec.blurb
                if meta and "inert" in meta[3]:
                    label += "  (nieaktywne w tej wersji)"
                row = ParamRow(name, spec, label, blurb, spec.default)
                row.connect("changed", self._on_row_changed)
                self.rows[name] = row
                box.append(row)
            exp.set_child(box)
            self.append(exp)

    def _on_row_changed(self, _row, name, value):
        self.emit("param-changed", name, value)

    def values(self) -> dict:
        return {n: r.get_value() for n, r in self.rows.items()}

    def apply_values(self, values: dict):
        for n, v in values.items():
            if n in self.rows:
                self.rows[n].set_value(v)

    def reset_all(self):
        for r in self.rows.values():
            r.set_value(r.default, emit=True)

    def set_sensitive_for(self, need: set[str]):
        """Wizualnie przygasza suwaki wymagające depth/motion, gdy dane niedostępne."""
        for n, r in self.rows.items():
            reqs = set(P.requires_of(n))
            ok = not (reqs & need)
            r.set_opacity(1.0 if ok else 0.45)
            r.set_tooltip_text(None if ok else
                               "Wymaga preanalizy głębi/ruchu — uruchom analizę zakresu.")


class TimecodeEntry(Gtk.Box):
    """Pole tekstowe akceptujące 'ss.ms' / 'm:ss.ms' / 'h:mm:ss.ms' / 'Nf' (numer klatki)."""

    __gsignals__ = {"changed-sec": (GObject.SignalFlags.RUN_FIRST, None, (float,))}

    def __init__(self, seconds: float = 0.0, fps: float = 25.0):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL)
        self.fps = fps
        self.entry = Gtk.Entry(width_chars=11)
        self.entry.set_text(fmt_tc(seconds))
        self.entry.connect("activate", self._commit)
        self.entry.connect("notify::has-focus", self._on_focus)
        self.append(self.entry)
        self._value = seconds

    def _on_focus(self, entry, _p):
        if not entry.get_property("has-focus"):
            self._commit()

    def _commit(self, *_a):
        v = parse_tc(self.entry.get_text(), self.fps)
        if v is None:
            self.entry.set_text(fmt_tc(self._value))
            return
        self.set_seconds(v, emit=True)

    def set_seconds(self, v: float, emit: bool = False):
        self._value = max(0.0, v)
        self.entry.set_text(fmt_tc(self._value))
        if emit:
            self.emit("changed-sec", self._value)

    def get_seconds(self) -> float:
        return self._value
