"""Cache preanaliz (depths.raw / motion.raw + sidecar JSON) i wyszukiwanie pokrycia zakresu."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
from dataclasses import dataclass, asdict
from pathlib import Path

from .media import MediaInfo
from .presets import CACHE_DIR


def canon_params(p: dict) -> dict:
    keys = ("proc-scale", "smooth-ksize", "flow-weight", "edge-weight")
    return {k: round(float(p[k]), 4) for k in keys if k in p}


def params_key(p: dict) -> str:
    return hashlib.sha1(json.dumps(canon_params(p), sort_keys=True).encode()).hexdigest()[:8]


@dataclass
class AnalysisMeta:
    vsig: str
    video: str
    width: int
    height: int
    fps_n: int
    fps_d: int
    first_frame: int
    frames: int
    depth: str
    motion: str | None
    motion_max_mag: float
    analyzer: dict
    pkey: str
    created: str = ""
    meta_path: str = ""

    @property
    def last_frame_excl(self) -> int:
        return self.first_frame + self.frames

    def covers(self, i0: int, i1: int) -> bool:
        return self.first_frame <= i0 and self.last_frame_excl >= i1

    def to_files(self) -> "DataFiles":
        return DataFiles(self.depth, self.motion, self.first_frame, self.frames,
                         self.width, self.height, self.motion_max_mag)

    def describe(self) -> str:
        m = " + flow" if self.motion else ""
        return f"głębia{m}: klatki {self.first_frame}–{self.last_frame_excl - 1} ({self.frames})"


@dataclass
class DataFiles:
    depth_path: str
    motion_path: str | None
    first_frame: int
    frames: int
    width: int
    height: int
    motion_max_mag: float

    @property
    def depth_frame_bytes(self) -> int:
        return self.width * self.height

    @property
    def motion_frame_bytes(self) -> int:
        return self.width * self.height * 2


class AnalysisCache:
    def __init__(self, root: Path | None = None):
        self.root = Path(root) if root else CACHE_DIR / "analysis"
        self.root.mkdir(parents=True, exist_ok=True)

    def base_for(self, info: MediaInfo, an_params: dict, motion: bool, max_mag: float,
                 i0: int, i1: int) -> Path:
        tag = f"{info.vsig}_{params_key(an_params)}_{i0}-{i1}{'_m' if motion else ''}"
        return self.root / tag

    def _load(self, f: Path) -> AnalysisMeta | None:
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            m = AnalysisMeta(**{k: d[k] for k in AnalysisMeta.__dataclass_fields__ if k in d})
            m.meta_path = str(f)
            return m
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def find(self, info: MediaInfo, an_params: dict, need_motion: bool, max_mag: float,
             i0: int, i1: int) -> AnalysisMeta | None:
        pk = params_key(an_params)
        best = None
        for f in self.root.glob("*.json"):
            m = self._load(f)
            if not m or m.vsig != info.vsig or m.pkey != pk:
                continue
            if (m.width, m.height) != (info.width, info.height) or not m.covers(i0, i1):
                continue
            if need_motion and not (m.motion and abs(m.motion_max_mag - max_mag) < 1e-6):
                continue
            try:
                if os.path.getsize(m.depth) < m.frames * m.width * m.height:
                    continue
                if need_motion and os.path.getsize(m.motion) < m.frames * m.width * m.height * 2:
                    continue
            except OSError:
                continue
            if best is None or m.frames < best.frames:
                best = m
        return best

    def register(self, meta: AnalysisMeta, base: Path) -> AnalysisMeta:
        meta.created = time.strftime("%Y-%m-%d %H:%M:%S")
        p = Path(str(base) + ".json")
        p.write_text(json.dumps(asdict(meta), indent=2), encoding="utf-8")
        meta.meta_path = str(p)
        return meta

    def size_bytes(self) -> int:
        return sum(f.stat().st_size for f in self.root.glob("*") if f.is_file())

    def clear(self):
        shutil.rmtree(self.root, ignore_errors=True)
        self.root.mkdir(parents=True, exist_ok=True)


def estimate_bytes(info: MediaInfo, frames: int, motion: bool) -> int:
    return frames * info.width * info.height * (3 if motion else 1)
