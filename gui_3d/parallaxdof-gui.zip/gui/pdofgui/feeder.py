"""RawFeeder — podaje plik .raw (depth/motion) do pluginu przez FIFO od dowolnej klatki.

Po co: parallaxdof czyta depth-file/motion-file ściśle sekwencyjnie (fread od początku,
otwierane w start()), bez mapowania klatek i bez obsługi seeków. Żeby test-run z
zakresu, pętla i przewijanie działały bez zmian w pluginie, każdy (re)start potoku
dostaje świeży FIFO, do którego wątek wpisuje dane od klatki startowej.
"""
from __future__ import annotations

import os
import tempfile
import threading
import time


class RawFeeder:
    def __init__(self, src_path: str, offset_bytes: int, tmpdir: str | None = None):
        if offset_bytes < 0:
            raise ValueError("Ujemne przesunięcie w pliku map (zakres poza analizą).")
        self.src = src_path
        self.offset = offset_bytes
        self.dir = tmpdir or tempfile.gettempdir()
        self.path = os.path.join(self.dir, f"pdof_{os.getpid()}_{id(self) & 0xffffff:x}.fifo")
        if os.path.exists(self.path):
            os.unlink(self.path)
        os.mkfifo(self.path, 0o600)
        self.written = 0
        self._stop = threading.Event()
        self._thr = threading.Thread(target=self._run, daemon=True, name="pdof-feeder")
        self._thr.start()

    def _run(self):
        fd = -1
        try:
            fd = os.open(self.path, os.O_WRONLY)      # blokuje do fopen() w pluginie
            with open(self.src, "rb", buffering=0) as f:
                f.seek(self.offset)
                while not self._stop.is_set():
                    chunk = f.read(1 << 20)
                    if not chunk:
                        break
                    mv = memoryview(chunk)
                    while mv and not self._stop.is_set():
                        n = os.write(fd, mv)
                        self.written += n
                        mv = mv[n:]
        except OSError:
            pass                                       # BrokenPipe: plugin zamknął plik
        finally:
            if fd >= 0:
                try:
                    os.close(fd)
                except OSError:
                    pass

    def close(self):
        """Wywołuj PO zatrzymaniu potoku (NULL) — wtedy zapis dostaje EPIPE i wątek kończy."""
        self._stop.set()
        for _ in range(20):
            if not self._thr.is_alive():
                break
            try:                                       # odblokuj writer czekający w open()
                fd = os.open(self.path, os.O_RDONLY | os.O_NONBLOCK)
                os.close(fd)
            except OSError:
                pass
            self._thr.join(0.05)
        try:
            os.unlink(self.path)
        except OSError:
            pass
