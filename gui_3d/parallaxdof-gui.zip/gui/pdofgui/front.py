"""Wspólny front-end dekodera + seek + budowa sinków — używany przez podgląd, joby i player."""
from __future__ import annotations

from .gsthelpers import Gst, GLib, make, link_pad


class Front:
    """uridecodebin z gwarancją: video → on_video(pad), audio → on_audio(pad), reszta → fakesink.
    on_ready() woła się w WĄTKU GŁÓWNYM po no-more-pads (potok gotowy na początkowy seek)."""

    def __init__(self, pipeline: Gst.Pipeline, uri: str, on_video, on_audio, on_ready):
        self.pipeline = pipeline
        self.on_video, self.on_audio, self.on_ready = on_video, on_audio, on_ready
        self._video_done = False
        self._ready_sent = False
        self.dec = make("uridecodebin", uri=uri)
        # tylko pamięć systemowa → videoconvert zawsze się dogada (bez GPU-memory)
        self.dec.set_property("caps", Gst.Caps.from_string("video/x-raw; audio/x-raw"))
        pipeline.add(self.dec)
        self.dec.connect("pad-added", self._pad_added)
        self.dec.connect("no-more-pads", self._no_more)

    def _pad_added(self, _dec, pad):
        caps = pad.get_current_caps() or pad.query_caps(None)
        name = caps.get_structure(0).get_name() if caps and caps.get_size() else ""
        if name.startswith("video/") and not self._video_done:
            self._video_done = True
            self.on_video(pad)
        elif name.startswith("audio/"):
            self.on_audio(pad)
        else:
            self.to_fakesink(pad)

    def to_fakesink(self, pad):
        fk = make("fakesink", sync=False, async_=False)
        self.pipeline.add(fk)
        fk.sync_state_with_parent()
        link_pad(pad, fk)

    def _no_more(self, _dec):
        GLib.idle_add(self._fire)

    def _fire(self):
        if not self._ready_sent:
            self._ready_sent = True
            self.on_ready()
        return False


def seek(pipeline: Gst.Pipeline, start_ns: int, stop_ns: int | None, rate: float = 1.0,
         segment: bool = False) -> bool:
    flags = Gst.SeekFlags.FLUSH | Gst.SeekFlags.ACCURATE
    if segment:
        flags |= Gst.SeekFlags.SEGMENT
    return pipeline.seek(rate, Gst.Format.TIME, flags,
                         Gst.SeekType.SET, int(start_ns),
                         Gst.SeekType.SET if stop_ns is not None else Gst.SeekType.NONE,
                         int(stop_ns) if stop_ns is not None else -1)


def seek_via_pad(pad: Gst.Pad, start_ns: int, stop_ns: int | None, rate: float = 1.0,
                 segment: bool = False) -> bool:
    """Seek wysłany w górę przez src-pad wewnątrz potoku (omija sinki — filesink/BYTES
    zgłaszałby GStreamer-CRITICAL przy seeku w TIME przez cały potok)."""
    flags = Gst.SeekFlags.FLUSH | Gst.SeekFlags.ACCURATE
    if segment:
        flags |= Gst.SeekFlags.SEGMENT
    ev = Gst.Event.new_seek(rate, Gst.Format.TIME, flags,
                            Gst.SeekType.SET, int(start_ns),
                            Gst.SeekType.SET if stop_ns is not None else Gst.SeekType.NONE,
                            int(stop_ns) if stop_ns is not None else -1)
    return pad.send_event(ev)
