"""Sondowanie plików wideo (Discoverer)."""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field

import gi

gi.require_version("Gst", "1.0")
gi.require_version("GstPbutils", "1.0")
from gi.repository import Gst, GstPbutils, GLib  # noqa: E402

from .gsthelpers import SECOND, frame_ns, ns_to_frame


@dataclass
class MediaInfo:
    path: str
    uri: str
    duration: float            # s
    width: int
    height: int
    fps_n: int
    fps_d: int
    has_audio: bool = False
    vcodec: str = ""
    acodec: str = ""
    fps_guessed: bool = False
    notes: list = field(default_factory=list)

    @property
    def fps(self) -> float:
        return self.fps_n / self.fps_d

    @property
    def frames(self) -> int:
        return max(1, int(round(self.duration * self.fps)))

    @property
    def frame_dur_ns(self) -> int:
        return frame_ns(1, self.fps_n, self.fps_d)

    def t_to_frame(self, sec: float) -> int:
        return ns_to_frame(int(sec * SECOND), self.fps_n, self.fps_d)

    def frame_to_t(self, i: int) -> float:
        return frame_ns(i, self.fps_n, self.fps_d) / SECOND

    @property
    def vsig(self) -> str:
        """Podpis pliku (ścieżka+rozmiar+mtime) do kluczy cache."""
        st = os.stat(self.path)
        raw = f"{os.path.realpath(self.path)}|{st.st_size}|{st.st_mtime_ns}"
        return hashlib.sha1(raw.encode()).hexdigest()[:10]

    def label(self) -> str:
        return (f"{self.width}×{self.height} · {self.fps:.3f} fps · {self.vcodec or '?'}"
                f"{' · audio' if self.has_audio else ''}")


def probe(path: str) -> MediaInfo:
    path = os.path.abspath(path)
    uri = GLib.filename_to_uri(path, None)
    disc = GstPbutils.Discoverer.new(15 * SECOND)
    info = disc.discover_uri(uri)
    res = info.get_result()
    if res != GstPbutils.DiscovererResult.OK:
        raise RuntimeError(f"Nie można odczytać pliku ({res.value_nick}).")
    vs = info.get_video_streams()
    if not vs:
        raise RuntimeError("Plik nie zawiera strumienia wideo.")
    v = vs[0]
    n, d = v.get_framerate_num(), v.get_framerate_denom()
    guessed = False
    if n <= 0 or d <= 0:
        n, d, guessed = 25, 1, True
    a = info.get_audio_streams()
    def _desc(stream):
        try:
            return GstPbutils.pb_utils_get_codec_description(stream.get_caps())
        except Exception:
            return ""
    mi = MediaInfo(
        path=path, uri=uri,
        duration=info.get_duration() / SECOND,
        width=v.get_width(), height=v.get_height(),
        fps_n=n, fps_d=d,
        has_audio=bool(a),
        vcodec=_desc(v), acodec=_desc(a[0]) if a else "",
        fps_guessed=guessed,
    )
    if guessed:
        mi.notes.append("Nie wykryto stałego fps — przyjęto 25 (mapowanie klatek może być przybliżone).")
    return mi
