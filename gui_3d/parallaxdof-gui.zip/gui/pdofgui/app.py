"""Punkt wejścia ParallaxDoF Studio.

WAŻNE dot. kolejności importów: import GStreamera (Gst) PRZED otwarciem
pierwszego okna GTK potrafi uniemożliwić GDK-owi otwarcie displaya — zaobserwowane
zarówno pod X11, jak i pod Wayland w środowisku testowym (Gtk.init_check() zwraca
sukces, ale Gdk.Display.get_default() zostaje None, i każde kolejne okno wywala
"Gtk couldn't be initialized"). Dlatego najpierw tworzymy realne okno GTK (to
wymusza poprawne otwarcie displaya), a dopiero PO TYM importujemy moduł
`mainwindow`, który jako pierwszy dotyka GStreamera (przez gsthelpers/media/jobs/...).
Ten plik sam w sobie nie importuje niczego związanego z Gst.
"""
from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio, GLib  # noqa: E402

APP_ID = "pl.stpf99.parallaxdofgui"


class App(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        win = self.props.active_window
        if win:
            win.present()
            return
        bootstrap = Gtk.ApplicationWindow(application=self)  # wymusza otwarcie displaya
        from . import gsthelpers as G
        from .mainwindow import MainWindow, alert
        bootstrap.destroy()
        missing = G.init_gst()
        win = MainWindow(self)
        if missing:
            alert(win, "Brak elementów GStreamera", "Nie znaleziono: " + ", ".join(missing) +
                 "\nZainstaluj brakujące pakiety pluginów GStreamera.")
        win.present()


def main():
    return App().run(None)


if __name__ == "__main__":
    main()
