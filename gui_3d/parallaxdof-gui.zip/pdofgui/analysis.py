"""Cache preanalizy głębi/ruchu (mapy na dysku + metadane JSON)."""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, asdict
from pathlib import Path

from .media import MediaInfo
from .presets import CACHE_DIR


def estimate_bytes(width: int, height: int, frames: int, need_motion: bool) -> int:
    """Szacunek rozmiaru cache (depth 1 B/px + opcjonalnie motion 2 B/px, po skali)."""
    px = max(1, width) * max(1, height)
    # depthanalyzer zapisuje zwykle w proc-scale; tu górne oszacowanie przy scale=1
    depth = px * frames
    motion = (px * 2 * frames) if need_motion else 0
    return depth + motion + 4096


@dataclass
class AnalysisMeta:
    vsig: str
    path: str                 # katalog wpisu cache
    i0: int
    i1: int
    width: int
    height: int
    fps_n: int
    fps_d: int
    an_params: dict
    need_motion: bool
    motion_max_mag: float
    depth_file: str = ""
    motion_file: str = ""
    created: float = 0.0

    def describe(self) -> str:
        n = max(0, self.i1 - self.i0)
        bits = ["głębia"]
        if self.need_motion:
            bits.append("ruch")
        return (f"klatki {self.i0}–{self.i1} ({n}), {self.width}×{self.height}, "
                f"{'+'.join(bits)}, max-mag={self.motion_max_mag:g}")

    def to_files(self) -> dict:
        out = {}
        if self.depth_file and os.path.isfile(self.depth_file):
            out["depth-file"] = self.depth_file
        if self.motion_file and os.path.isfile(self.motion_file):
            out["motion-file"] = self.motion_file
        return out

    def covers(self, i0: int, i1: int) -> bool:
        return self.i0 <= i0 and self.i1 >= i1

    def params_match(self, an_params: dict, need_motion: bool, max_mag: float) -> bool:
        if bool(need_motion) != bool(self.need_motion):
            return False
        if need_motion and abs(float(max_mag) - float(self.motion_max_mag)) > 1e-6:
            return False
        for k, v in an_params.items():
            if k == "motion-max-mag":
                continue
            sv = self.an_params.get(k)
            if sv is None:
                return False
            try:
                if abs(float(sv) - float(v)) > 1e-6:
                    return False
            except (TypeError, ValueError):
                if sv != v:
                    return False
        return True


class AnalysisCache:
    """Prosty magazyn: ~/.cache/parallaxdof-gui/analysis/<vsig>_<hash>/."""

    def __init__(self, root: Path | None = None):
        self.root = Path(root) if root else CACHE_DIR / "analysis"
        self.root.mkdir(parents=True, exist_ok=True)

    def _key_dir(self, info: MediaInfo, an_params: dict, need_motion: bool, max_mag: float) -> Path:
        import hashlib
        payload = json.dumps({
            "vsig": info.vsig,
            "params": {k: float(v) for k, v in sorted(an_params.items())},
            "motion": bool(need_motion),
            "max_mag": float(max_mag),
        }, sort_keys=True)
        h = hashlib.sha1(payload.encode()).hexdigest()[:12]
        return self.root / f"{info.vsig}_{h}"

    def find(self, info: MediaInfo, an_params: dict, need_motion: bool,
             max_mag: float, i0: int, i1: int) -> AnalysisMeta | None:
        # przeszukaj wszystkie wpisy dla tego vsig (różne zakresy / parametry)
        for d in self.root.glob(f"{info.vsig}_*"):
            meta_path = d / "meta.json"
            if not meta_path.is_file():
                continue
            try:
                data = json.loads(meta_path.read_text(encoding="utf-8"))
                meta = AnalysisMeta(**{k: data[k] for k in AnalysisMeta.__dataclass_fields__ if k in data})
            except (OSError, ValueError, TypeError, KeyError):
                continue
            if not meta.params_match(an_params, need_motion, max_mag):
                continue
            if not meta.covers(i0, i1):
                continue
            # pliki muszą istnieć
            if need_motion and not (meta.motion_file and os.path.isfile(meta.motion_file)):
                continue
            if not (meta.depth_file and os.path.isfile(meta.depth_file)):
                # depth zawsze wymagany gdy mode != realtime; find wołane tylko wtedy
                if not need_motion and not meta.depth_file:
                    continue
                if meta.depth_file and not os.path.isfile(meta.depth_file):
                    continue
            return meta
        return None

    def register(self, info: MediaInfo, i0: int, i1: int, an_params: dict,
                 need_motion: bool, max_mag: float, depth_file: str, motion_file: str = "") -> AnalysisMeta:
        d = self._key_dir(info, an_params, need_motion, max_mag)
        d.mkdir(parents=True, exist_ok=True)
        meta = AnalysisMeta(
            vsig=info.vsig, path=str(d), i0=i0, i1=i1,
            width=info.width, height=info.height, fps_n=info.fps_n, fps_d=info.fps_d,
            an_params=dict(an_params), need_motion=bool(need_motion),
            motion_max_mag=float(max_mag),
            depth_file=depth_file, motion_file=motion_file or "",
            created=time.time(),
        )
        (d / "meta.json").write_text(json.dumps(asdict(meta), ensure_ascii=False, indent=2),
                                     encoding="utf-8")
        return meta

    def size_bytes(self) -> int:
        total = 0
        for root, _dirs, files in os.walk(self.root):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return total

    def clear(self):
        import shutil
        if self.root.exists():
            shutil.rmtree(self.root, ignore_errors=True)
        self.root.mkdir(parents=True, exist_ok=True)
