"""Drobne narzędzia wokół GStreamera: init, tworzenie elementów, czas, timecode."""
from __future__ import annotations

import os
import re
from pathlib import Path

import gi

gi.require_version("Gst", "1.0")
gi.require_version("GstPbutils", "1.0")
from gi.repository import Gst, GLib  # noqa: E402

SECOND = Gst.SECOND


# ─────────────────────────────── init ────────────────────────────────────────
def _plugin_dir_candidates():
    env = os.environ.get("PDOF_PLUGIN_DIR")
    if env:
        yield Path(env)
    here = Path(__file__).resolve()
    # gst-parallaxdof/gui/pdofgui/gsthelpers.py  →  gst-parallaxdof/build
    for up in (2, 1, 3):
        try:
            yield here.parents[up] / "build"
        except IndexError:
            pass
    yield Path.cwd() / "build"


def init_gst() -> list[str]:
    """Inicjalizuje GStreamer, dokłada build/ pluginu do GST_PLUGIN_PATH.
    Zwraca listę brakujących elementów krytycznych (pusta = OK)."""
    for c in _plugin_dir_candidates():
        if (c / "libgstparallaxdof.so").exists():
            cur = os.environ.get("GST_PLUGIN_PATH", "")
            if str(c) not in cur.split(":"):
                os.environ["GST_PLUGIN_PATH"] = f"{c}:{cur}" if cur else str(c)
            break
    Gst.init(None)
    need = ["parallaxdof", "depthanalyzer", "uridecodebin", "videoconvert",
            "tee", "queue", "capsfilter", "fakesink"]
    return [n for n in need if Gst.ElementFactory.find(n) is None]


def have(factory: str) -> bool:
    return Gst.ElementFactory.find(factory) is not None


def make(factory: str, name: str | None = None, **props) -> Gst.Element:
    el = Gst.ElementFactory.make(factory, name)
    if el is None:
        raise RuntimeError(f"Brak elementu GStreamera „{factory}” (doinstaluj odpowiedni pakiet pluginów).")
    for k, v in props.items():
        set_prop(el, k.replace("_", "-"), v)
    return el


def set_prop(el: Gst.Element, name: str, value):
    """Ustawia właściwość z koercją typu wg GParamSpec (int/double/enum/string...)."""
    ps = el.find_property(name)
    if ps is None:
        return False
    tn = ps.value_type.name
    try:
        if tn in ("gint", "guint", "gint64", "guint64", "glong", "gulong"):
            el.set_property(name, int(round(float(value))))
        elif tn in ("gdouble", "gfloat"):
            el.set_property(name, float(value))
        elif tn == "gboolean":
            el.set_property(name, bool(value))
        elif tn == "gchararray":
            el.set_property(name, None if value in (None, "") else str(value))
        elif isinstance(value, str) or tn.startswith("Gst") or "Enum" in tn or "Flags" in tn:
            Gst.util_set_object_arg(el, name, str(value))
        else:
            el.set_property(name, value)
    except Exception:
        Gst.util_set_object_arg(el, name, str(value))
    return True


def add_link(pipeline: Gst.Pipeline, *els: Gst.Element):
    for e in els:
        pipeline.add(e)
    for a, b in zip(els, els[1:]):
        if not a.link(b):
            raise RuntimeError(f"Nie można połączyć {a.get_name()} → {b.get_name()}")


def req_pad(el: Gst.Element, templ: str):
    f = getattr(el, "request_pad_simple", None) or el.get_request_pad
    return f(templ)


def link_pad(src_pad: Gst.Pad, sink_el: Gst.Element) -> bool:
    sp = sink_el.get_static_pad("sink")
    if sp is None or sp.is_linked():
        return False
    return src_pad.link(sp) == Gst.PadLinkReturn.OK


def block_buffers(pad: Gst.Pad):
    """Blokuje przepływ BUFORÓW przez pad (zdarzenia caps/segment przechodzą).
    Zwraca id sondy; zwolnienie: pad.remove_probe(id)."""
    return pad.add_probe(Gst.PadProbeType.BLOCK | Gst.PadProbeType.BUFFER,
                         lambda p, i: Gst.PadProbeReturn.OK)


# ─────────────────────────────── czas ────────────────────────────────────────
def frame_ns(i: int, fps_n: int, fps_d: int) -> int:
    return (int(i) * SECOND * fps_d) // fps_n


def ns_to_frame(ns: int, fps_n: int, fps_d: int) -> int:
    return int(round(ns * fps_n / (SECOND * fps_d)))


def fmt_tc(sec: float, ms: bool = True) -> str:
    if sec is None or sec != sec:
        sec = 0.0
    sign = "-" if sec < 0 else ""
    sec = abs(sec)
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = sec % 60
    frac = f"{s:06.3f}" if ms else f"{int(s):02d}"
    return f"{sign}{h}:{m:02d}:{frac}" if h else f"{sign}{m:02d}:{frac}"


_TC = re.compile(r"^\s*(?:(?:(\d+):)?(\d+):)?(\d+(?:[.,]\d+)?)\s*$")


def parse_tc(text: str, fps: float = 25.0) -> float | None:
    """'12.5' | '1:02.5' | '1:02:03.5' | 'f250' | '250f' → sekundy (None = błąd)."""
    t = (text or "").strip().lower()
    m = re.fullmatch(r"f\s*(\d+)|(\d+)\s*f", t)
    if m:
        return int(m.group(1) or m.group(2)) / fps
    m = _TC.match(t)
    if not m:
        return None
    h, mi, s = m.groups()
    return int(h or 0) * 3600 + int(mi or 0) * 60 + float(s.replace(",", "."))


def idle(fn, *a):
    """Wykonaj w wątku głównym (bezpieczne z wątków strumieniujących)."""
    GLib.idle_add(lambda: (fn(*a), False)[1])


def preroll(pipe: Gst.Pipeline, timeout_ns: int = 5 * SECOND) -> bool:
    """PAUSED + czekaj na ASYNC_DONE / gotowy stan. False = timeout/błąd."""
    if pipe is None:
        return False
    ret = pipe.set_state(Gst.State.PAUSED)
    if ret == Gst.StateChangeReturn.FAILURE:
        return False
    ret, _st, _pend = pipe.get_state(timeout_ns)
    return ret == Gst.StateChangeReturn.SUCCESS


def safe_seek(pipe: Gst.Pipeline, start_ns: int, stop_ns: int | None = None,
              rate: float = 1.0, accurate: bool = False) -> bool:
    """Seek w formacie TIME dopiero gdy segment jest gotowy.

    Unika: gst_segment_do_seek: assertion 'segment->format == format' failed
    """
    if pipe is None:
        return False
    if not preroll(pipe):
        return False
    ok, _dur = pipe.query_duration(Gst.Format.TIME)
    if not ok:
        bus = pipe.get_bus()
        bus.timed_pop_filtered(500 * Gst.MSECOND, Gst.MessageType.ASYNC_DONE)
        ok, _dur = pipe.query_duration(Gst.Format.TIME)
        if not ok:
            return False

    flags = Gst.SeekFlags.FLUSH
    flags |= Gst.SeekFlags.ACCURATE if accurate else Gst.SeekFlags.KEY_UNIT
    start_ns = max(0, int(start_ns))
    if stop_ns is None or stop_ns <= start_ns:
        return bool(pipe.seek(rate, Gst.Format.TIME, flags,
                              Gst.SeekType.SET, start_ns,
                              Gst.SeekType.NONE, 0))
    return bool(pipe.seek(rate, Gst.Format.TIME, flags,
                          Gst.SeekType.SET, start_ns,
                          Gst.SeekType.SET, int(stop_ns)))
