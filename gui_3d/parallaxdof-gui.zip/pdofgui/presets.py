"""Presety (wbudowane + użytkownika) i ustawienia aplikacji (JSON w ~/.config)."""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path

CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "parallaxdof-gui"
CACHE_DIR = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "parallaxdof-gui"

BUILTIN = {
    "Domyślne": ({}, "Wartości domyślne pluginu."),
    "Delikatna mimoza": ({"parallax-shift": 8, "fg-sharpness": 1.2},
                          "Subtelny efekt — bezpieczny do pierwszego podejrzenia."),
    "Mocna mimoza": ({"parallax-shift": 24, "fg-sharpness": 2.4},
                      "Wyraźne przesunięcie i gain — na ruchliwym materiale może być męczące."),
    "Pasma głębi (README)": ({"parallax-shift": 15, "depth-bands": 4, "near-gain": 2.2,
                              "far-gain": 0.15, "band-blur": 4.0},
                             "Przykład z README: pierwszy plan pulsuje mocniej niż tło. Wymaga map głębi."),
    "Clarity w centrum": ({"saliency-boost": 1.5, "saliency-radius": 0.5, "saliency-sigma": 2.5},
                           "Lokalny kontrast w środku kadru (jak suwak Clarity)."),
    "Wiggle 3D — subtelny": ({"wiggle-amount": 4.0, "wiggle-freq-hz": 3.0},
                              "Delikatna kinetyczna paralaksa (3–8 px praktycznie bez artefaktów). Wymaga map głębi."),
    "Wiggle 3D — mocny": ({"wiggle-amount": 9.0, "wiggle-freq-hz": 4.0},
                           "Wyraźny efekt Smooth3D. Wymaga map głębi."),
    "Głębia + ruch (README)": ({"parallax-shift": 15, "depth-bands": 4, "near-gain": 2.2, "far-gain": 0.15,
                                "saliency-boost": 1.5, "motion-saliency-weight": 0.7,
                                "motion-saliency-gamma": 1.3},
                               "Przykład z README z realnym flow i kontrastem od prędkości. "
                               "Wymaga preanalizy głębi + flow."),
}


def _slug(name: str) -> str:
    s = re.sub(r"[^\w\-]+", "_", name.strip(), flags=re.UNICODE).strip("_")
    return s[:60] or "preset"


class PresetStore:
    def __init__(self, directory: Path | None = None):
        self.dir = Path(directory) if directory else CONFIG_DIR / "presets"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.user: dict[str, dict] = {}
        self.reload()

    def reload(self):
        self.user.clear()
        for f in sorted(self.dir.glob("*.json")):
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
                if isinstance(d.get("params"), dict) and d.get("name"):
                    d["_file"] = str(f)
                    self.user[d["name"]] = d
            except (OSError, ValueError):
                continue

    def names(self) -> list[tuple[str, bool]]:
        """[(nazwa, wbudowany?)] — wbudowane najpierw."""
        return [(n, True) for n in BUILTIN] + [(n, False) for n in sorted(self.user)]

    def is_builtin(self, name: str) -> bool:
        return name in BUILTIN

    def get(self, name: str) -> dict:
        if name in BUILTIN:
            return dict(BUILTIN[name][0])
        return dict(self.user.get(name, {}).get("params", {}))

    def description(self, name: str) -> str:
        if name in BUILTIN:
            return BUILTIN[name][1]
        return self.user.get(name, {}).get("description", "")

    def save(self, name: str, params: dict, description: str = "") -> str:
        name = name.strip()
        if not name:
            raise ValueError("Pusta nazwa presetu.")
        if name in BUILTIN:
            name += " (moje)"
        path = self.dir / f"{_slug(name)}.json"
        old = self.user.get(name)
        if old and old.get("_file"):
            path = Path(old["_file"])
        data = {"name": name, "description": description, "params": params,
                "saved": time.strftime("%Y-%m-%d %H:%M:%S"), "app": "parallaxdof-gui"}
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        self.reload()
        return name

    def delete(self, name: str):
        d = self.user.get(name)
        if d and d.get("_file"):
            try:
                os.remove(d["_file"])
            except OSError:
                pass
        self.reload()

    def export(self, name: str, path: str):
        data = {"name": name, "description": self.description(name), "params": self.get(name),
                "app": "parallaxdof-gui"}
        Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def import_file(self, path: str) -> str:
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(d.get("params"), dict):
            raise ValueError("To nie jest plik presetu (brak pola „params”).")
        return self.save(d.get("name") or Path(path).stem, d["params"], d.get("description", ""))


class Settings:
    """Prosty magazyn JSON z autozapisem."""
    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path else CONFIG_DIR / "settings.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self.data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.data = {}

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
        try:
            self.path.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass
