"""ParallaxDoF Studio — GUI (GTK4 + GStreamer) do pluginu gst-parallaxdof."""
__version__ = "1.0.0"
