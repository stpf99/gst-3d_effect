"""Widgety UI: panel parametrów efektu i pole timecode."""
from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gdk, GObject  # noqa: E402

from . import params as P
from . import gsthelpers as G


class TimecodeEntry(Gtk.Box):
    """Pole tekstowe timecode: '12.5' | '1:02.5' | '1:02:03.5' | 'f250'.

    Sygnał: changed-sec(self) — po zatwierdzeniu (Enter / focus-out).
    """

    __gsignals__ = {
        "changed-sec": (GObject.SignalFlags.RUN_FIRST, None, ()),
    }

    def __init__(self, seconds: float = 0.0):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.fps = 25.0
        self._sec = float(seconds)
        self._entry = Gtk.Entry(width_chars=12, max_width_chars=14)
        self._entry.set_text(G.fmt_tc(self._sec))
        self._entry.connect("activate", self._commit)
        ctrl = Gtk.EventControllerFocus()
        ctrl.connect("leave", lambda *_: (self._commit(), Gdk.EVENT_PROPAGATE)[1])
        self._entry.add_controller(ctrl)
        self.append(self._entry)

    def _commit(self, *_a):
        parsed = G.parse_tc(self._entry.get_text(), self.fps)
        if parsed is None:
            self._entry.set_text(G.fmt_tc(self._sec))
            return
        if abs(parsed - self._sec) > 1e-6:
            self._sec = parsed
            self._entry.set_text(G.fmt_tc(self._sec))
            self.emit("changed-sec")
        else:
            self._entry.set_text(G.fmt_tc(self._sec))

    def get_seconds(self) -> float:
        return self._sec

    def set_seconds(self, sec: float, emit: bool = False):
        self._sec = float(sec or 0.0)
        self._entry.set_text(G.fmt_tc(self._sec))
        if emit:
            self.emit("changed-sec")


class ParamPanel(Gtk.Box):
    """Siatka suwaków/spinów dla właściwości parallaxdof (z grupami).

    Sygnał: param-changed(self, name: str, value: float)
    """

    __gsignals__ = {
        "param-changed": (GObject.SignalFlags.RUN_FIRST, None, (str, float)),
    }

    def __init__(self, specs: dict[str, P.PSpec]):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.specs = P.editable(specs)
        self._rows: dict[str, tuple[Gtk.Widget, Gtk.SpinButton | Gtk.Scale]] = {}
        self._by_req: dict[str, list[str]] = {"depth": [], "motion": [], "saliency": [], "realtime": []}

        groups: dict[str, list[str]] = {g: [] for g, _ in P.GROUPS}
        for name in self.specs:
            meta = P.PDOF_META.get(name)
            g = meta[0] if meta else "other"
            if g not in groups:
                groups[g] = []
            groups[g].append(name)
            for r in P.requires_of(name):
                if r in self._by_req:
                    self._by_req[r].append(name)

        for gkey, glabel in P.GROUPS:
            names = groups.get(gkey) or []
            if not names:
                continue
            frame = Gtk.Frame(label=glabel)
            grid = Gtk.Grid(column_spacing=10, row_spacing=4,
                            margin_start=8, margin_end=8, margin_top=6, margin_bottom=6)
            frame.set_child(grid)
            self.append(frame)
            for row, name in enumerate(names):
                self._add_row(grid, row, name)

        # nieznane właściwości pluginu (poza PDOF_META)
        other = [n for n in self.specs if n not in P.PDOF_META]
        if other:
            frame = Gtk.Frame(label="Inne")
            grid = Gtk.Grid(column_spacing=10, row_spacing=4,
                            margin_start=8, margin_end=8, margin_top=6, margin_bottom=6)
            frame.set_child(grid)
            self.append(frame)
            for row, name in enumerate(other):
                self._add_row(grid, row, name)

    def _add_row(self, grid: Gtk.Grid, row: int, name: str):
        spec = self.specs[name]
        meta = P.PDOF_META.get(name)
        label_txt = meta[1] if meta else name
        blurb = meta[2] if meta else (spec.blurb or "")
        inert = P.is_inert(name)
        lbl = Gtk.Label(label=label_txt, xalign=0, tooltip_text=blurb or name)
        if inert:
            lbl.add_css_class("pdof-dim")
        grid.attach(lbl, 0, row, 1, 1)

        spin = Gtk.SpinButton()
        spin.set_range(spec.minimum, spec.maximum)
        spin.set_increments(spec.step, max(spec.step * 5, 1))
        spin.set_digits(spec.digits)
        spin.set_value(float(spec.default if spec.default is not None else spec.minimum))
        spin.set_hexpand(True)
        spin.set_sensitive(not inert)
        spin.connect("value-changed", self._on_spin, name)
        grid.attach(spin, 1, row, 1, 1)
        self._rows[name] = (lbl, spin)

    def _on_spin(self, spin: Gtk.SpinButton, name: str):
        self.emit("param-changed", name, spin.get_value())

    def values(self) -> dict:
        return {n: spin.get_value() for n, (_l, spin) in self._rows.items()}

    def apply_values(self, vals: dict):
        for n, v in vals.items():
            pair = self._rows.get(n)
            if pair is None:
                continue
            _l, spin = pair
            spin.handler_block_by_func(self._on_spin)
            try:
                spin.set_value(float(v))
            finally:
                spin.handler_unblock_by_func(self._on_spin)

    def reset_all(self):
        for n, (_l, spin) in self._rows.items():
            d = self.specs[n].default
            if d is None:
                continue
            spin.handler_block_by_func(self._on_spin)
            try:
                spin.set_value(float(d))
            finally:
                spin.handler_unblock_by_func(self._on_spin)
            self.emit("param-changed", n, float(d))

    def set_sensitive_for(self, disabled_sources: set):
        """Wyłącza parametry wymagające źródeł z disabled_sources (depth/motion/…)."""
        for src, names in self._by_req.items():
            sens = src not in disabled_sources
            for n in names:
                pair = self._rows.get(n)
                if pair is None:
                    continue
                lbl, spin = pair
                if P.is_inert(n):
                    continue
                spin.set_sensitive(sens)
                if sens:
                    lbl.remove_css_class("pdof-dim")
                else:
                    lbl.add_css_class("pdof-dim")
