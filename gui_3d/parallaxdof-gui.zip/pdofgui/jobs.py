"""Zadania w tle: preanaliza (depthanalyzer) i eksport (parallaxdof + encoder)."""
from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass
from pathlib import Path

import gi

gi.require_version("Gst", "1.0")
from gi.repository import Gst, GLib  # noqa: E402

from . import gsthelpers as G
from .analysis import AnalysisCache, AnalysisMeta
from .media import MediaInfo


@dataclass
class EncSettings:
    codec: str = "x264enc"          # etykieta z available_codecs()
    container: str = "mp4"       # tylko mp4
    rc: str = "bitrate"          # quality | bitrate  (x264: quantizer / bitrate)
    quality: int = 23            # x264 quantizer / CRF-like
    bitrate: int = 4000          # kb/s  (jak w działającym gst-launch)
    speed: str = "medium"        # ultrafast/medium/slow
    audio: str = "aac"           # aac | none


# (etykieta UI, factory GStreamer) — software, zgodne z działającym pipeline
_CODEC_FACTORIES: list[tuple[str, list[str]]] = [
    ("x264enc", ["x264enc"]),
    ("x265enc", ["x265enc"]),
]


def _resolve_factory(label: str) -> str | None:
    for name, factories in _CODEC_FACTORIES:
        if name == label:
            for f in factories:
                if G.have(f):
                    return f
            return None
    # fallback x264
    if G.have("x264enc"):
        return "x264enc"
    return None


def available_codecs() -> list[str]:
    """Software H.264/H.265 (jak w działającym gst-launch z parallaxdof)."""
    out = []
    for label, factories in _CODEC_FACTORIES:
        if any(G.have(f) for f in factories):
            out.append(label)
    return out


def available_containers() -> list[str]:
    """Wyłącznie MP4."""
    return ["mp4"] if G.have("mp4mux") else []


def _idle(fn, *a):
    GLib.idle_add(lambda: (fn(*a), False)[1])


class _GstJob:
    """Wspólna baza: wątek + bus watch + cancel."""

    def __init__(self, on_progress=None, on_done=None):
        self.on_progress = on_progress
        self.on_done = on_done
        self.finished = False
        self._cancel = False
        self._pipe: Gst.Pipeline | None = None
        self._thread: threading.Thread | None = None
        self._t0 = 0.0
        self._last_p = 0.0

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def cancel(self):
        self._cancel = True
        p = self._pipe
        if p is not None:
            try:
                p.send_event(Gst.Event.new_eos())
            except Exception:
                pass
            try:
                p.set_state(Gst.State.NULL)
            except Exception:
                pass

    def _set_state(self, st: Gst.State):
        if self._pipe:
            self._pipe.set_state(st)

    def _progress(self, p: float, frames_done: int = 0):
        p = max(0.0, min(1.0, p))
        now = time.monotonic()
        dt = max(1e-3, now - self._t0)
        fps = frames_done / dt if frames_done else 0.0
        eta = ((1.0 - p) / p * dt) if p > 0.02 else 0.0
        if self.on_progress and (p - self._last_p > 0.005 or p >= 1.0):
            self._last_p = p
            _idle(self.on_progress, p, fps, eta)

    def _finish(self, ok: bool, err: str = ""):
        self.finished = True
        if self._pipe:
            try:
                self._pipe.set_state(Gst.State.NULL)
            except Exception:
                pass
            self._pipe = None
        if self.on_done:
            _idle(self.on_done, self, ok, err)


class AnalysisJob(_GstJob):
    """Uruchamia depthanalyzer na zakresie [i0, i1) i rejestruje wynik w cache.

    Wątek roboczy z własną GLib.MainLoop — uridecodebin/decodebin wymaga
    iteracji kontekstu, inaczej pad-added nie odpala i „nic nie rusza”.
    """

    def __init__(self, info: MediaInfo, i0: int, i1: int, an_params: dict,
                 need_motion: bool, max_mag: float, cache: AnalysisCache,
                 on_progress=None, on_done=None):
        super().__init__(on_progress, on_done)
        self.info = info
        self.i0, self.i1 = int(i0), int(i1)
        self.an_params = dict(an_params)
        self.need_motion = bool(need_motion)
        self.max_mag = float(max_mag)
        self.cache = cache
        self.meta: AnalysisMeta | None = None
        self._loop: GLib.MainLoop | None = None

    def cancel(self):
        self._cancel = True
        p = self._pipe
        if p is not None:
            try:
                p.send_event(Gst.Event.new_eos())
            except Exception:
                pass
        if self._loop is not None:
            try:
                self._loop.quit()
            except Exception:
                pass
        super().cancel()

    def _run(self):
        self._t0 = time.monotonic()
        info = self.info
        nframes = max(1, self.i1 - self.i0)
        out_dir = self.cache._key_dir(info, self.an_params, self.need_motion, self.max_mag)
        out_dir.mkdir(parents=True, exist_ok=True)
        depth_path = str(out_dir / "depth.raw")
        motion_path = str(out_dir / "motion.raw") if self.need_motion else ""

        # usuń stare pliki, żeby nie brać cache-u po nieudanym runie
        for path in (depth_path, motion_path):
            if path and os.path.isfile(path):
                try:
                    os.remove(path)
                except OSError:
                    pass

        if not G.have("depthanalyzer"):
            self._finish(False, "Brak elementu depthanalyzer — zbuduj/zainstaluj plugin")
            return

        ctx = GLib.MainContext.new()
        ctx.push_thread_default()
        loop = GLib.MainLoop.new(ctx, False)
        self._loop = loop

        try:
            pipe = Gst.Pipeline.new("analysis")
            self._pipe = pipe

            # filesrc jest pewniejszy niż uridecodebin w osobnym wątku
            src = G.make("filesrc", "fs", location=info.path)
            dbin = G.make("decodebin", "dbin")
            q = G.make("queue", "q", max_size_buffers=8, leaky=2)
            conv = G.make("videoconvert", "conv")
            # depthanalyzer (jak parallaxdof) zwykle chce BGR
            caps = G.make(
                "capsfilter", "bgr",
                caps=Gst.Caps.from_string("video/x-raw,format=BGR"),
            )
            analyzer = G.make("depthanalyzer", "an")
            sink = G.make("fakesink", "sink", sync=False)
            G.set_prop(sink, "async", False)

            for k, v in self.an_params.items():
                G.set_prop(analyzer, k.replace("_", "-"), v)
            G.set_prop(analyzer, "motion-max-mag", self.max_mag)

            # różne możliwe nazwy właściwości wyjścia
            wrote_depth = False
            for prop, val in (
                ("depth-file", depth_path),
                ("depth-path", depth_path),
                ("depth-location", depth_path),
                ("location", depth_path),
            ):
                if analyzer.find_property(prop):
                    G.set_prop(analyzer, prop, val)
                    wrote_depth = True
                    break
            if self.need_motion:
                for prop, val in (
                    ("motion-file", motion_path),
                    ("motion-path", motion_path),
                    ("motion-location", motion_path),
                ):
                    if analyzer.find_property(prop):
                        G.set_prop(analyzer, prop, val)
                        break
            for prop, val in (("start-frame", self.i0), ("end-frame", self.i1),
                              ("first-frame", self.i0), ("last-frame", self.i1 - 1)):
                if analyzer.find_property(prop):
                    G.set_prop(analyzer, prop, val)

            pipe.add(src)
            pipe.add(dbin)
            G.add_link(pipe, q, conv, caps, analyzer, sink)
            if not src.link(dbin):
                raise RuntimeError("filesrc → decodebin: link failed")

            linked = {"ok": False}

            def on_pad(_db, pad):
                if linked["ok"]:
                    return
                caps_p = pad.get_current_caps() or pad.query_caps(None)
                st = caps_p.get_structure(0) if caps_p and caps_p.get_size() else None
                if st is None:
                    return
                name = st.get_name()
                if not name.startswith("video/"):
                    return
                sinkpad = q.get_static_pad("sink")
                if sinkpad is None or sinkpad.is_linked():
                    return
                if pad.link(sinkpad) == Gst.PadLinkReturn.OK:
                    linked["ok"] = True

            dbin.connect("pad-added", on_pad)

            bus = pipe.get_bus()
            bus.add_signal_watch()

            start_ns = G.frame_ns(self.i0, info.fps_n, info.fps_d)
            stop_ns = G.frame_ns(self.i1, info.fps_n, info.fps_d)
            result = {"ok": False, "err": ""}

            def on_bus(_bus, msg):
                if msg.type == Gst.MessageType.ERROR:
                    err, dbg = msg.parse_error()
                    result["err"] = f"{err.message}" + (f" ({dbg})" if dbg else "")
                    loop.quit()
                elif msg.type == Gst.MessageType.EOS:
                    result["ok"] = True
                    loop.quit()
                elif msg.type == Gst.MessageType.ASYNC_DONE:
                    # po preroll — seek zakresu
                    if not linked["ok"]:
                        # jeszcze nie ma wideo — czekaj
                        return
                    G.safe_seek(pipe, start_ns, stop_ns, rate=1.0, accurate=False)
                return True

            bus.connect("message", on_bus)

            # timeout postępu
            def tick():
                if self._cancel:
                    loop.quit()
                    return False
                if self._pipe is None:
                    return False
                ok, pos = self._pipe.query_position(Gst.Format.TIME)
                if ok and stop_ns > start_ns:
                    p = max(0.0, min(1.0, (pos - start_ns) / (stop_ns - start_ns)))
                    self._progress(p, int(p * nframes))
                elif linked["ok"]:
                    # choćby mrugnięcie, że żyje
                    self._progress(min(0.01, self._last_p + 0.001), 0)
                return True

            GLib.timeout_add(200, tick)

            ret = pipe.set_state(Gst.State.PLAYING)
            if ret == Gst.StateChangeReturn.FAILURE:
                self._finish(False, "Pipeline analysis: set_state(PLAYING) failed")
                return

            # watchdog: jeśli po 15s zero linku wideo — błąd
            def watchdog():
                if not linked["ok"] and not result["err"]:
                    result["err"] = (
                        "Brak strumienia wideo z decodebin (pad-added nie zadziałał). "
                        "Sprawdź, czy plik się dekoduje: gst-launch-1.0 filesrc location=… ! decodebin ! fakesink"
                    )
                    loop.quit()
                return False

            GLib.timeout_add_seconds(15, watchdog)

            loop.run()

            pipe.set_state(Gst.State.NULL)

            if self._cancel:
                self._finish(False, "Anulowano")
                return
            if result["err"]:
                self._finish(False, result["err"])
                return

            # szukaj plików wyjściowych
            if not os.path.isfile(depth_path) or os.path.getsize(depth_path) == 0:
                for cand in sorted(out_dir.glob("*")):
                    if cand.is_file() and cand.stat().st_size > 0:
                        n = cand.name.lower()
                        if "depth" in n or n.endswith(".raw"):
                            depth_path = str(cand)
                            break
            if self.need_motion and (not os.path.isfile(motion_path) or os.path.getsize(motion_path) == 0):
                for cand in sorted(out_dir.glob("*")):
                    if cand.is_file() and "motion" in cand.name.lower() and cand.stat().st_size > 0:
                        motion_path = str(cand)
                        break

            if not os.path.isfile(depth_path) or os.path.getsize(depth_path) == 0:
                props = [ps.name for ps in analyzer.list_properties()]
                self._finish(
                    False,
                    "depthanalyzer nie zapisał mapy głębi. "
                    f"Właściwości elementu: {', '.join(props)}. "
                    "Upewnij się, że depth-file/location jest ustawiane."
                )
                return

            self.meta = self.cache.register(
                info, self.i0, self.i1, self.an_params,
                self.need_motion, self.max_mag, depth_path,
                motion_path if self.need_motion else "",
            )
            self._progress(1.0, nframes)
            self._finish(True, "")
        except Exception as e:  # noqa: BLE001
            self._finish(False, str(e))
        finally:
            try:
                ctx.pop_thread_default()
            except Exception:
                pass
            self._loop = None
            if self._pipe is not None:
                try:
                    self._pipe.set_state(Gst.State.NULL)
                except Exception:
                    pass


class EncodeJob(_GstJob):
    """Koduje zakres przez parallaxdof (lub passthrough dla Oryginału)."""

    def __init__(self, info: MediaInfo, i0: int, i1: int, target: str, params: dict,
                 mode: str, data: dict | None, settings: EncSettings, out_path: str,
                 on_progress=None, on_done=None, meta_extra: dict | None = None):
        super().__init__(on_progress, on_done)
        self.info = info
        self.i0, self.i1 = int(i0), int(i1)
        self.target = target
        self.params = dict(params or {})
        self.mode = mode
        self.data = data or {}
        self.settings = settings
        self.out_path = out_path
        self.meta_extra = meta_extra or {}
        self._pdof = None

    def set_param(self, name: str, value):
        """Korekta parametru w locie (jeśli element żyje)."""
        el = self._pdof
        if el is not None:
            G.idle(lambda: G.set_prop(el, name.replace("_", "-"), value))

    def _encoder_elements(self):
        """x264enc / x265enc — jak w działającym gst-launch."""
        s = self.settings
        factory = _resolve_factory(s.codec) or "x264enc"
        if not G.have(factory):
            raise RuntimeError(
                f"Brak enkodera {factory}. Zainstaluj gstreamer1.0-plugins-ugly "
                "(x264enc) lub plugins-bad (x265enc)."
            )
        enc = G.make(factory, "venc")

        if factory == "x264enc":
            # bitrate w kbps; speed-preset; opcjonalnie quantizer
            if s.rc == "quality":
                # tryb quantizer (zbliżony do CRF)
                if enc.find_property("quantizer"):
                    G.set_prop(enc, "quantizer", max(0, min(50, int(s.quality))))
                if enc.find_property("pass"):
                    try:
                        Gst.util_set_object_arg(enc, "pass", "quant")
                    except Exception:
                        pass
            else:
                G.set_prop(enc, "bitrate", int(s.bitrate))
            speed_map = {"fast": "ultrafast", "medium": "medium", "slow": "slow"}
            if enc.find_property("speed-preset"):
                try:
                    Gst.util_set_object_arg(enc, "speed-preset", speed_map.get(s.speed, "medium"))
                except Exception:
                    pass
            if enc.find_property("tune"):
                try:
                    Gst.util_set_object_arg(enc, "tune", "film")
                except Exception:
                    pass
            if enc.find_property("key-int-max"):
                G.set_prop(enc, "key-int-max", 60)
        elif factory == "x265enc":
            if s.rc == "quality" and enc.find_property("qp"):
                G.set_prop(enc, "qp", max(0, min(51, int(s.quality))))
            elif enc.find_property("bitrate"):
                G.set_prop(enc, "bitrate", int(s.bitrate))
            if enc.find_property("speed-preset"):
                try:
                    Gst.util_set_object_arg(enc, "speed-preset",
                                           {"fast": "ultrafast", "medium": "medium",
                                            "slow": "slow"}.get(s.speed, "medium"))
                except Exception:
                    pass
        return enc

    def _parser_for_codec(self):
        factory = _resolve_factory(self.settings.codec) or ""
        if "264" in factory and G.have("h264parse"):
            return G.make("h264parse", "parse")
        if "265" in factory and G.have("h265parse"):
            return G.make("h265parse", "parse")
        return None

    def _mux_factory(self) -> str:
        return "mp4mux"

    def _run(self):
        self._t0 = time.monotonic()
        info = self.info
        nframes = max(1, self.i1 - self.i0)
        start_ns = G.frame_ns(self.i0, info.fps_n, info.fps_d)
        stop_ns = G.frame_ns(self.i1, info.fps_n, info.fps_d)

        try:
            pipe = Gst.Pipeline.new(f"encode-{self.target}")
            self._pipe = pipe
            src = G.make("uridecodebin", "src", uri=info.uri)
            vqueue = G.make("queue", "vq", max_size_buffers=8)
            conv = G.make("videoconvert", "vconv")

            # parallaxdof wymaga BGR (jak w działającym gst-launch)
            use_pdof = self.target in ("A", "B") and G.have("parallaxdof")
            caps_bgr = None
            pdof = None
            conv2 = None
            if use_pdof:
                caps_bgr = G.make(
                    "capsfilter", "bgr",
                    caps=Gst.Caps.from_string("video/x-raw,format=BGR"),
                )
                pdof = G.make("parallaxdof", "pdof")
                self._pdof = pdof
                for k, v in self.params.items():
                    G.set_prop(pdof, k.replace("_", "-"), v)
                if self.mode != "realtime":
                    if "depth-file" in self.data:
                        G.set_prop(pdof, "depth-file", self.data["depth-file"])
                    if "motion-file" in self.data:
                        G.set_prop(pdof, "motion-file", self.data["motion-file"])
                    # motion-max-mag z pliku analizy / parametrów
                    mm = self.params.get("motion-max-mag")
                    if mm is not None:
                        G.set_prop(pdof, "motion-max-mag", mm)
                conv2 = G.make("videoconvert", "vconv2")

            enc = self._encoder_elements()
            parse = self._parser_for_codec()

            mux = G.make(self._mux_factory(), "mux")
            sink = G.make("filesink", "fsink", location=self.out_path, sync=False)

            # Łańcuch jak w gst-launch:
            #   decode → videoconvert → [BGR → parallaxdof → videoconvert] → x264enc → h264parse → mp4mux
            pipe.add(src)
            G.add_link(pipe, vqueue, conv)
            chain = []
            if use_pdof:
                chain.extend([caps_bgr, pdof, conv2])
            chain.append(enc)
            if parse:
                chain.append(parse)
            G.add_link(pipe, *chain)
            if not conv.link(chain[0]):
                raise RuntimeError(f"link conv→{chain[0].get_name()} failed")
            last_v = chain[-1]
            G.add_link(pipe, mux, sink)
            if not last_v.link(mux):
                raise RuntimeError(f"link {last_v.get_name()}→mux failed")

            # audio (tylko AAC do MP4)
            aqueue = None
            if self.settings.audio != "none" and info.has_audio:
                aqueue = G.make("queue", "aq")
                aconv = G.make("audioconvert", "aconv")
                ares = G.make("audioresample", "ares")
                afactory = None
                for cand in ("avenc_aac", "voaacenc", "faac", "fdkaacenc"):
                    if G.have(cand):
                        afactory = cand
                        break
                if afactory:
                    aenc = G.make(afactory, "aenc")
                    ap = G.make("aacparse", "aparse") if G.have("aacparse") else None
                    pipe.add(aqueue)
                    pipe.add(aconv)
                    pipe.add(ares)
                    pipe.add(aenc)
                    aqueue.link(aconv)
                    aconv.link(ares)
                    ares.link(aenc)
                    if ap:
                        pipe.add(ap)
                        aenc.link(ap)
                        ap.link(mux)
                    else:
                        aenc.link(mux)
                else:
                    aqueue = None  # brak enkodera AAC — pomiń audio

            v_linked = {"ok": False}
            a_linked = {"ok": False}

            def on_pad(_dbin, pad):
                caps = pad.get_current_caps() or pad.query_caps(None)
                s = caps.get_structure(0) if caps else None
                if not s:
                    return
                name = s.get_name()
                if name.startswith("video/") and not v_linked["ok"]:
                    sp = vqueue.get_static_pad("sink")
                    if sp and not sp.is_linked():
                        if pad.link(sp) == Gst.PadLinkReturn.OK:
                            v_linked["ok"] = True
                elif name.startswith("audio/") and aqueue is not None and not a_linked["ok"]:
                    sp = aqueue.get_static_pad("sink")
                    if sp and not sp.is_linked():
                        if pad.link(sp) == Gst.PadLinkReturn.OK:
                            a_linked["ok"] = True

            src.connect("pad-added", on_pad)

            bus = pipe.get_bus()
            if not G.safe_seek(pipe, start_ns, stop_ns, rate=1.0, accurate=False):
                pipe.set_state(Gst.State.PAUSED)
                pipe.get_state(5 * Gst.SECOND)
            pipe.set_state(Gst.State.PLAYING)

            while not self._cancel:
                msg = bus.timed_pop_filtered(
                    200 * Gst.MSECOND,
                    Gst.MessageType.ERROR | Gst.MessageType.EOS,
                )
                if msg is None:
                    ok, pos = pipe.query_position(Gst.Format.TIME)
                    if ok and stop_ns > start_ns:
                        p = (pos - start_ns) / (stop_ns - start_ns)
                        self._progress(p, int(p * nframes))
                    continue
                if msg.type == Gst.MessageType.ERROR:
                    err, dbg = msg.parse_error()
                    self._finish(False, f"{err.message}")
                    return
                if msg.type == Gst.MessageType.EOS:
                    break

            if self._cancel:
                self._finish(False, "Anulowano")
                return
            self._progress(1.0, nframes)
            self._finish(True, "")
        except Exception as e:  # noqa: BLE001
            self._finish(False, str(e))
