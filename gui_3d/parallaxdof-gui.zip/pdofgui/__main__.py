"""Uruchomienie: python3 -m pdofgui"""
from __future__ import annotations

import os
import sys

import gi

# GTK4 MUSI być załadowane przed pluginami GStreamera z GTK,
# inaczej gtksink (GTK3) może zarejestrować typy i zabić aplikację.
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
gi.require_version("Gst", "1.0")
from gi.repository import Gtk, Gio  # noqa: E402

from . import gsthelpers as G
from .mainwindow import MainWindow, APP_ID


class Application(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        missing = G.init_gst()
        extra = []
        if not G.have("gtk4paintablesink"):
            extra.append("gtk4paintablesink (pakiet: gstreamer1.0-gtk4)")
        win = MainWindow(self)
        if missing or extra:
            from .mainwindow import alert
            alert(win, "Brak elementów GStreamera",
                  "Zainstaluj / zbuduj plugin i ustaw GST_PLUGIN_PATH.\n"
                  "Brakuje: " + ", ".join(list(missing) + extra))
        win.present()


def main(argv=None):
    # Wyłącz ranking gtksink (GTK3), żeby nikt go nie wybrał automatycznie
    os.environ.setdefault("GST_PLUGIN_FEATURE_RANK", "gtksink:NONE")
    app = Application()
    return app.run(argv or sys.argv)


if __name__ == "__main__":
    sys.exit(main())
