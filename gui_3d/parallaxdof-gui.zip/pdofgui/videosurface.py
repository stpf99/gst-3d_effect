"""Powierzchnia wideo GTK4: Gtk.Picture + opcjonalny podpis (caption)."""
from __future__ import annotations

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GObject  # noqa: E402


class VideoSurface(Gtk.Overlay):
    """Widget podglądu: czarne tło + Picture (paintable z gtk4paintablesink) + podpis."""

    def __init__(self, caption: str = ""):
        super().__init__()
        self.add_css_class("pdof-video")
        self.set_overflow(Gtk.Overflow.HIDDEN)

        self._picture = Gtk.Picture(content_fit=Gtk.ContentFit.CONTAIN)
        self._picture.set_hexpand(True)
        self._picture.set_vexpand(True)
        self.set_child(self._picture)

        self._caption = Gtk.Label(label=caption or "", css_classes=["pdof-caption"],
                                  halign=Gtk.Align.START, valign=Gtk.Align.END,
                                  margin_start=8, margin_bottom=8)
        self._caption.set_visible(bool(caption))
        self.add_overlay(self._caption)

        self._paintable = None

    def set_caption(self, text: str):
        self._caption.set_label(text or "")
        self._caption.set_visible(bool(text))

    def set_paintable(self, paintable):
        """Podłącza Gdk.Paintable z gtk4paintablesink (lub None)."""
        self._paintable = paintable
        self._picture.set_paintable(paintable)

    def clear(self):
        self._paintable = None
        self._picture.set_paintable(None)
