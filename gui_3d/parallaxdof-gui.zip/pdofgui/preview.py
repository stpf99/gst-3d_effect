"""Silnik podglądu na żywo: dwa widoki (Oryginał / A / B) z parallaxdof."""
from __future__ import annotations

import gi

gi.require_version("Gst", "1.0")
from gi.repository import Gst, GLib  # noqa: E402

from . import gsthelpers as G
from .media import MediaInfo
from .videosurface import VideoSurface


class PreviewEngine:
    """Jeden uridecodebin → tee → gałęzie (orig / pdof A / pdof B) → paintablesinki.

    Publiczne API zgodne z mainwindow.py:
      views, params, data_mode, i0, i1, loop, mute, state
      on_state, on_error
      launch, toggle, step, seek, set_rate, set_mute, set_param, position_ns, stop
    """

    def __init__(self, info: MediaInfo, surfaces: list[VideoSurface]):
        self.info = info
        self.surfaces = list(surfaces)
        self.views = ["orig", "A"]
        self.params: dict[str, dict] = {"A": {}, "B": {}}
        self.data_mode = "realtime"
        self.i0 = 0
        self.i1 = info.frames
        self.loop = True
        self.mute = True
        self.state = "stopped"
        self.on_state = None
        self.on_error = None

        self._pipe: Gst.Pipeline | None = None
        self._pdof: dict[str, Gst.Element] = {}
        self._rate = 1.0
        self._bus_watch = None
        self._data_files: dict = {}

    # ── publiczne ────────────────────────────────────────────────────────────
    def set_param(self, slot: str, name: str, value):
        el = self._pdof.get(slot)
        if el is not None:
            G.set_prop(el, name.replace("_", "-"), value)
        self.params.setdefault(slot, {})[name] = value

    def set_mute(self, mute: bool):
        self.mute = mute
        if self._pipe:
            vol = self._pipe.get_by_name("vol")
            if vol:
                G.set_prop(vol, "mute", mute)

    def set_rate(self, rate: float):
        self._rate = float(rate) or 1.0
        if self.state in ("playing", "paused"):
            pos = self.position_ns()
            self.seek(pos)

    def position_ns(self) -> int:
        if not self._pipe:
            return 0
        ok, pos = self._pipe.query_position(Gst.Format.TIME)
        return int(pos) if ok else 0

    def stop(self):
        self._teardown()
        self._set_state("stopped")

    def toggle(self):
        if self.state == "playing":
            if self._pipe:
                self._pipe.set_state(Gst.State.PAUSED)
            self._set_state("paused")
        elif self.state in ("paused", "stopped"):
            if self._pipe is None:
                self.launch(None, True)
            else:
                self._pipe.set_state(Gst.State.PLAYING)
                self._set_state("playing")

    def step(self, n: int):
        pos = self.position_ns()
        frame = G.ns_to_frame(pos, self.info.fps_n, self.info.fps_d) + int(n)
        frame = max(self.i0, min(self.i1 - 1, frame))
        self.launch(frame, False)

    def seek(self, pos_ns: int):
        if not self._pipe:
            return
        stop = G.frame_ns(self.i1, self.info.fps_n, self.info.fps_d)
        G.safe_seek(self._pipe, int(pos_ns), stop, rate=self._rate, accurate=True)

    def launch(self, frame: int | None, play: bool):
        """Przebudowuje potok (gdy zmiana widoków/trybu) i seekuje."""
        self._set_state("loading")
        need_rebuild = self._pipe is None or self._views_changed()
        if need_rebuild:
            self._build()
        if self._pipe is None:
            self._set_state("error")
            return
        start_frame = self.i0 if frame is None else int(frame)
        start_ns = G.frame_ns(start_frame, self.info.fps_n, self.info.fps_d)
        stop_ns = G.frame_ns(self.i1, self.info.fps_n, self.info.fps_d)
        if not G.safe_seek(self._pipe, start_ns, stop_ns, rate=self._rate, accurate=False):
            # bez seeka — po prostu odpal od początku pliku
            G.preroll(self._pipe)
        if play:
            self._pipe.set_state(Gst.State.PLAYING)
            self._set_state("playing")
        else:
            self._pipe.set_state(Gst.State.PAUSED)
            self._set_state("paused")

    # ── wewnętrzne ───────────────────────────────────────────────────────────
    def _set_state(self, st: str):
        self.state = st
        if self.on_state:
            G.idle(self.on_state, st)

    def _error(self, msg: str):
        if self.on_error:
            G.idle(self.on_error, msg)
        self._set_state("error")

    def _views_changed(self) -> bool:
        # uproszczone: zawsze przebuduj przy launch gdy data_mode/views mogą się zmienić
        return True

    def _teardown(self):
        if self._bus_watch and self._pipe:
            try:
                self._pipe.get_bus().remove_watch()
            except Exception:
                pass
            self._bus_watch = None
        if self._pipe:
            self._pipe.set_state(Gst.State.NULL)
            self._pipe = None
        self._pdof.clear()
        for s in self.surfaces:
            s.clear()

    def _make_sink(self, name: str, surface: VideoSurface):
        # NIGDY nie używaj gtksink (GTK3) w aplikacji GTK4 — powoduje
        # "cannot register existing type 'GtkWidget'".
        if G.have("gtk4paintablesink"):
            sink = G.make("gtk4paintablesink", name)
            try:
                paintable = sink.get_property("paintable")
                G.idle(lambda s=surface, p=paintable: s.set_paintable(p))
            except Exception:
                pass
            G.set_prop(sink, "sync", True)
            return sink
        # fallback: osobne okno / brak osadzenia w GUI
        for factory in ("glimagesink", "ximagesink", "waylandsink", "autovideosink"):
            if G.have(factory):
                sink = G.make(factory, name)
                G.set_prop(sink, "sync", True)
                return sink
        return G.make("fakesink", name, sync=True)

    def _build(self):
        self._teardown()
        info = self.info
        pipe = Gst.Pipeline.new("preview")
        src = G.make("uridecodebin", "src", uri=info.uri)
        tee = G.make("tee", "tee", allow_not_linked=True)

        pipe.add(src)
        pipe.add(tee)

        # audio (opcjonalnie, jeden sink)
        a_chain = []
        if info.has_audio:
            aq = G.make("queue", "aq")
            aconv = G.make("audioconvert", "aconv")
            ares = G.make("audioresample", "ares")
            vol = G.make("volume", "vol", mute=self.mute)
            asink = G.make("autoaudiosink", "asink") if G.have("autoaudiosink") else G.make("fakesink", "asink", sync=True)
            G.add_link(pipe, aq, aconv, ares, vol, asink)
            a_chain = [aq]

        # gałęzie wideo wg self.views (max 2 surfaces)
        used = set()
        for idx, kind in enumerate(self.views[: len(self.surfaces)]):
            surface = self.surfaces[idx]
            q = G.make("queue", f"q{idx}", max_size_buffers=3)
            conv = G.make("videoconvert", f"conv{idx}")
            els = [q, conv]

            if kind in ("A", "B") and G.have("parallaxdof"):
                pdof = G.make("parallaxdof", f"pdof{kind}")
                for k, v in self.params.get(kind, {}).items():
                    G.set_prop(pdof, k.replace("_", "-"), v)
                if self.data_mode != "realtime" and self._data_files:
                    if "depth-file" in self._data_files:
                        G.set_prop(pdof, "depth-file", self._data_files["depth-file"])
                    if "motion-file" in self._data_files and "motion" in self.data_mode:
                        G.set_prop(pdof, "motion-file", self._data_files["motion-file"])
                self._pdof[kind] = pdof
                conv2 = G.make("videoconvert", f"conv2{idx}")
                els.extend([pdof, conv2])

            sink = self._make_sink(f"sink{idx}", surface)
            els.append(sink)
            G.add_link(pipe, *els)

            # request pad z tee
            tpad = G.req_pad(tee, "src_%u")
            if tpad is None or not G.link_pad(tpad, q):
                self._error(f"Nie można podłączyć gałęzi widoku {kind}")
                self._teardown()
                return

            used.add(kind)

        def on_pad(_d, pad):
            caps = pad.get_current_caps() or pad.query_caps(None)
            st = caps.get_structure(0) if caps else None
            if not st:
                return
            n = st.get_name()
            if n.startswith("video/"):
                sp = tee.get_static_pad("sink")
                if sp and not sp.is_linked():
                    pad.link(sp)
            elif n.startswith("audio/") and a_chain:
                sp = a_chain[0].get_static_pad("sink")
                if sp and not sp.is_linked():
                    pad.link(sp)

        src.connect("pad-added", on_pad)
        bus = pipe.get_bus()
        self._bus_watch = bus.add_watch(GLib.PRIORITY_DEFAULT, self._on_bus)
        self._pipe = pipe

    def _on_bus(self, bus, msg):
        if msg.type == Gst.MessageType.ERROR:
            err, dbg = msg.parse_error()
            self._error(f"{err.message}")
        elif msg.type == Gst.MessageType.EOS:
            if self.loop:
                G.idle(lambda: self.launch(self.i0, True))
            else:
                if self._pipe:
                    self._pipe.set_state(Gst.State.PAUSED)
                self._set_state("paused")
        return True

    def set_data_files(self, files: dict):
        """Ustawia ścieżki depth-file / motion-file z cache (przed launch)."""
        self._data_files = dict(files or {})
