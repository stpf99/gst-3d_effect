"""Schemat parametrów: zakresy/domyślne z INTROSPEKCJI zainstalowanego pluginu,
metadane (etykiety, grupy, flagi) — zweryfikowane z gstparallaxdof.cpp v0.2.0."""
from __future__ import annotations

from dataclasses import dataclass

from .gsthelpers import Gst

# ── grupy w kolejności wyświetlania ──────────────────────────────────────────
GROUPS = [
    ("main",   "Efekt podstawowy (mimoza transwektorowa)"),
    ("bands",  "Pasma głębi"),
    ("wiggle", "Wiggle 3D (paralaksa kinetyczna)"),
    ("sal",    "Detal lokalny (saliency boost)"),
    ("rt",     "Tryb realtime (bez map)"),
    ("files",  "Kwantyzacja ruchu"),
    ("legacy", "Bez wpływu w tej wersji pluginu"),
    ("other",  "Inne (nowe właściwości pluginu)"),
]

# name: (grupa, etykieta, opis, flagi, wymaga)
#   flagi:   'restart' = zmiana wymaga restartu potoku (nie działa w locie)
#            'inert'   = właściwość nie jest czytana w transform_frame
#            'managed' = ustawiane przez aplikację (pliki)
#   wymaga:  'depth' | 'motion' | 'saliency' | 'realtime'
PDOF_META = {
    "parallax-shift": ("main", "Siła / przesunięcie (px)",
        "Siła efektu „mimozy”: przesunięcie residuału wzdłuż wektora ruchu, w pikselach.", (), ()),
    "fg-sharpness": ("main", "Gain residuału",
        "W tej wersji pluginu to gain mimozy: gain = wartość × 0.25 (przycięte do 0.05…2.0). "
        "Nazwa „sharpness” jest historyczna.", (), ()),
    "depth-bands": ("bands", "Liczba pasm głębi",
        "1 = wyłączone. >1: mapa głębi dzielona na N pasm z osobnym wzmocnieniem "
        "(od far-gain do near-gain).", (), ("depth",)),
    "near-gain": ("bands", "Gain: najbliższe pasmo",
        "Mnożnik residuału dla najjaśniejszego (najbliższego) pasma. Konwencja: jaśniej = bliżej.", (), ("depth",)),
    "far-gain": ("bands", "Gain: najdalsze pasmo",
        "Mnożnik residuału dla najciemniejszego (najdalszego) pasma.", (), ("depth",)),
    "band-blur": ("bands", "Rozmycie granic pasm (σ)",
        "Wygładza maskę gainu — zapobiega schodkowaniu na granicach pasm.", (), ("depth",)),
    "wiggle-amount": ("wiggle", "Amplituda wiggle (px)",
        "Realne poziome przesunięcie pikseli zależne od głębi, oscylujące w czasie. 0 = wyłączone. "
        "Powyżej ~15–20 px widać rozciągnięte krawędzie.", (), ("depth",)),
    "wiggle-freq-hz": ("wiggle", "Częstotliwość wiggle (Hz)",
        "Typowo 2–6 Hz. <1 Hz = kołysanie kadru, >10 Hz = migotanie.", (), ("depth",)),
    "saliency-boost": ("sal", "Siła detalu (0 = wył.)",
        "Lokalne wzmocnienie kontrastu/detalu (unsharp), ważone maską uwagi. 0 = wyłączone.", (), ()),
    "saliency-radius": ("sal", "Promień maski centralnej",
        "Ułamek połowy przekątnej kadru. Maska jest cache’owana per rozdzielczość, więc zmiana "
        "wymaga restartu potoku (aplikacja zrobi to sama).", ("restart",), ("saliency",)),
    "saliency-sigma": ("sal", "Sigma detalu (σ)",
        "Mniejsza = drobniejsze detale są wzmacniane.", (), ("saliency",)),
    "depth-saliency-weight": ("sal", "Udział głębi w masce",
        "0 = czyste centrum, 1 = czysta mapa głębi.", (), ("depth", "saliency")),
    "depth-saliency-gamma": ("sal", "Gamma głębi → waga",
        ">1 wzmacnia bliskie obiekty, <1 dalsze.", (), ("depth", "saliency")),
    "motion-saliency-weight": ("sal", "Udział prędkości w masce",
        "Szybciej poruszające się piksele dostają mocniejszy detal. Wymaga motion-file.", (), ("motion", "saliency")),
    "motion-saliency-gamma": ("sal", "Gamma prędkości → waga",
        ">1 tylko najszybsze piksele, <1 spłaszcza różnice.", (), ("motion", "saliency")),
    "proc-scale": ("rt", "Skala estymacji (realtime)",
        "Tylko bez map głębi/ruchu. Zmiana zwalnia bufor poprzedniej klatki w wątku głównym — "
        "dlatego wymaga restartu potoku.", ("restart",), ("realtime",)),
    "motion-max-mag": ("files", "Clamp prędkości (px/klatkę)",
        "MUSI równać się wartości użytej przy zapisie motion-file. Aplikacja ustawia to sama "
        "z metadanych analizy.", (), ("motion",)),
    # ── odczytywane tylko w set/get/init — nigdy w transform_frame (zweryfikowane w kodzie) ──
    "fg-threshold": ("legacy", "Próg pierwszego planu", "Nieużywane przez parallaxdof v0.2.0.", ("inert",), ()),
    "bg-blur": ("legacy", "Rozmycie tła", "Nieużywane przez parallaxdof v0.2.0.", ("inert",), ()),
    "max-fg-clusters": ("legacy", "Maks. skupisk FG", "Nieużywane przez parallaxdof v0.2.0.", ("inert",), ()),
    "smooth-ksize": ("legacy", "Wygładzanie głębi (ksize)",
        "Nieużywane przez parallaxdof (działa w depthanalyzer).", ("inert",), ()),
    "flow-weight": ("legacy", "Waga flow", "Nieużywane przez parallaxdof (działa w depthanalyzer).", ("inert",), ()),
    "edge-weight": ("legacy", "Waga krawędzi", "Nieużywane przez parallaxdof (działa w depthanalyzer).", ("inert",), ()),
    "depth-file": ("other", "depth-file", "", ("managed",), ()),
    "motion-file": ("other", "motion-file", "", ("managed",), ()),
}

ANALYZER_META = {
    "proc-scale": ("Skala estymacji", "Rozdzielczość, w której liczona jest głębia i flow (0.1–1.0). Mniejsza = szybciej."),
    "smooth-ksize": ("Wygładzanie mapy głębi", "Rozmiar jądra Gaussa (wymuszane nieparzyste)."),
    "flow-weight": ("Waga różnicy klatek / flow", "Udział ruchu w mapie głębi."),
    "edge-weight": ("Waga krawędzi (Sobel)", "Udział krawędzi w mapie głębi."),
    "motion-max-mag": ("Clamp prędkości (px/kl.)", "Zakres kwantyzacji magnitude w motion-file. Musi być taki sam przy odczycie."),
}
SKIP_PROPS = {"name", "parent", "qos"}


@dataclass
class PSpec:
    name: str
    kind: str            # int | float | bool | string | other
    minimum: float = 0.0
    maximum: float = 0.0
    default: object = None
    blurb: str = ""

    @property
    def step(self) -> float:
        if self.kind == "int":
            return 1.0
        span = self.maximum - self.minimum
        if span <= 2.5:
            return 0.01
        if span <= 12:
            return 0.05
        if span <= 60:
            return 0.1
        return 0.5

    @property
    def digits(self) -> int:
        if self.kind == "int":
            return 0
        return 2 if self.step < 0.1 else 1


def introspect(factory: str) -> dict[str, PSpec]:
    el = Gst.ElementFactory.make(factory)
    out: dict[str, PSpec] = {}
    if el is None:
        return out
    for ps in el.list_properties():
        if ps.name in SKIP_PROPS:
            continue
        tn = ps.value_type.name
        if tn in ("gint", "guint", "gint64", "guint64"):
            kind = "int"
        elif tn in ("gdouble", "gfloat"):
            kind = "float"
        elif tn == "gboolean":
            kind = "bool"
        elif tn == "gchararray":
            kind = "string"
        else:
            kind = "other"
        sp = PSpec(ps.name, kind, blurb=ps.blurb or "")
        if kind in ("int", "float"):
            sp.minimum, sp.maximum, sp.default = ps.minimum, ps.maximum, ps.default_value
        else:
            sp.default = getattr(ps, "default_value", None)
        out[ps.name] = sp
    return out


def editable(specs: dict[str, PSpec]) -> dict[str, PSpec]:
    """Właściwości parallaxdof edytowalne suwakiem (liczbowe, nie-'managed')."""
    res = {}
    for n, s in specs.items():
        meta = PDOF_META.get(n)
        if meta and "managed" in meta[3]:
            continue
        if s.kind in ("int", "float"):
            res[n] = s
    return res


def defaults(specs: dict[str, PSpec]) -> dict:
    return {n: s.default for n, s in editable(specs).items()}


def clamp(specs: dict[str, PSpec], values: dict) -> dict:
    """Przycina/zaokrągla wartości do zakresów pluginu; nieznane klucze pomija."""
    out = {}
    for n, v in values.items():
        s = specs.get(n)
        if s is None or s.kind not in ("int", "float"):
            continue
        try:
            v = float(v)
        except (TypeError, ValueError):
            continue
        v = min(max(v, s.minimum), s.maximum)
        out[n] = int(round(v)) if s.kind == "int" else v
    return out


def requires_of(name: str) -> tuple:
    m = PDOF_META.get(name)
    return m[4] if m else ()


def is_restart(name: str) -> bool:
    m = PDOF_META.get(name)
    return bool(m and "restart" in m[3])


def is_inert(name: str) -> bool:
    m = PDOF_META.get(name)
    return bool(m and "inert" in m[3])


def needs_of_params(values: dict, specs: dict[str, PSpec]) -> set[str]:
    """Jakich danych potrzebują niedomyślne parametry ('depth'/'motion')."""
    need = set()
    dflt = defaults(specs)
    for n, v in values.items():
        if n in dflt and abs(float(v) - float(dflt[n])) > 1e-9:
            for r in requires_of(n):
                if r in ("depth", "motion"):
                    need.add(r)
    return need
