"""Prosty odtwarzacz jednego pliku → VideoSurface (okno wyników)."""
from __future__ import annotations

import gi

gi.require_version("Gst", "1.0")
from gi.repository import Gst, GLib  # noqa: E402

from . import gsthelpers as G
from .media import MediaInfo
from .videosurface import VideoSurface


class SimplePlayer:
    """Odtwarzanie z pętlą IN/OUT, step klatka po klatce, seek."""

    def __init__(self, info: MediaInfo, surface: VideoSurface, mute: bool = False):
        self.info = info
        self.surface = surface
        self.mute = mute
        self.loop = True
        self.state = "stopped"
        self._i0 = 0
        self._i1 = info.frames
        self._pipe: Gst.Pipeline | None = None
        self._sink = None
        self._bus_watch = None
        self._rate = 1.0
        self._build()

    def _build(self):
        self._teardown_pipe()
        pipe = Gst.Pipeline.new("simple-player")
        src = G.make("uridecodebin", "src", uri=self.info.uri)
        conv = G.make("videoconvert", "conv")
        q = G.make("queue", "q")

        # NIGDY gtksink (GTK3) w app GTK4 — konflikt typów GObject.
        sink = None
        if G.have("gtk4paintablesink"):
            sink = G.make("gtk4paintablesink", "sink")
            try:
                paintable = sink.get_property("paintable")
                G.idle(lambda: self.surface.set_paintable(paintable))
            except Exception:
                pass
        else:
            for factory in ("glimagesink", "ximagesink", "waylandsink", "autovideosink"):
                if G.have(factory):
                    sink = G.make(factory, "sink")
                    break
            if sink is None:
                sink = G.make("fakesink", "sink", sync=True)

        G.set_prop(sink, "sync", True)
        self._sink = sink

        vol = None
        aconv = None
        asink = None
        if self.info.has_audio:
            aconv = G.make("audioconvert", "aconv")
            ares = G.make("audioresample", "ares")
            vol = G.make("volume", "vol", mute=self.mute)
            asink = G.make("autoaudiosink", "asink") if G.have("autoaudiosink") else G.make("fakesink", "asink")

        pipe.add(src)
        G.add_link(pipe, q, conv, sink)
        if aconv is not None:
            G.add_link(pipe, aconv, ares, vol, asink)

        def on_pad(_d, pad):
            caps = pad.get_current_caps() or pad.query_caps(None)
            st = caps.get_structure(0) if caps else None
            if not st:
                return
            n = st.get_name()
            if n.startswith("video/"):
                sp = q.get_static_pad("sink")
                if sp and not sp.is_linked():
                    pad.link(sp)
            elif n.startswith("audio/") and aconv is not None:
                sp = aconv.get_static_pad("sink")
                if sp and not sp.is_linked():
                    pad.link(sp)

        src.connect("pad-added", on_pad)
        self._pipe = pipe
        bus = pipe.get_bus()
        self._bus_watch = bus.add_watch(GLib.PRIORITY_DEFAULT, self._on_bus)

    def _on_bus(self, bus, msg):
        if msg.type == Gst.MessageType.ERROR:
            err, _dbg = msg.parse_error()
            self.state = "error"
        elif msg.type == Gst.MessageType.EOS:
            if self.loop:
                self.launch(self._i0, True)
            else:
                self.state = "paused"
                self._pipe.set_state(Gst.State.PAUSED)
        return True

    def _teardown_pipe(self):
        if self._bus_watch and self._pipe:
            try:
                self._pipe.get_bus().remove_watch()
            except Exception:
                pass
            self._bus_watch = None
        if self._pipe:
            self._pipe.set_state(Gst.State.NULL)
            self._pipe = None
        self._sink = None

    def teardown(self):
        self._teardown_pipe()
        self.surface.clear()
        self.state = "stopped"

    def set_in(self, i0: int):
        self._i0 = max(0, int(i0))

    def set_out(self, i1: int):
        self._i1 = max(self._i0 + 1, int(i1))

    def mid(self, i: int) -> int:
        return int(i)

    def launch(self, frame: int | None, play: bool):
        if self._pipe is None:
            self._build()
        pipe = self._pipe
        start = G.frame_ns(frame if frame is not None else self._i0, self.info.fps_n, self.info.fps_d)
        stop = G.frame_ns(self._i1, self.info.fps_n, self.info.fps_d)
        if not G.safe_seek(pipe, start, stop, rate=self._rate, accurate=False):
            G.preroll(pipe)
        if play:
            pipe.set_state(Gst.State.PLAYING)
            self.state = "playing"
        else:
            pipe.set_state(Gst.State.PAUSED)
            self.state = "paused"

    def play(self):
        self.launch(self._i0, True)

    def toggle(self):
        if self.state == "playing":
            if self._pipe:
                self._pipe.set_state(Gst.State.PAUSED)
            self.state = "paused"
        else:
            if self._pipe:
                self._pipe.set_state(Gst.State.PLAYING)
            self.state = "playing"

    def step(self, n: int):
        pos = self.position_ns()
        frame = G.ns_to_frame(pos, self.info.fps_n, self.info.fps_d) + int(n)
        frame = max(self._i0, min(self._i1 - 1, frame))
        was = self.state == "playing"
        self.launch(frame, False)
        if was:
            # po stepie zostajemy w pauzie (jak typowy edytor)
            pass

    def seek(self, pos_ns: int):
        if not self._pipe:
            return
        stop = G.frame_ns(self._i1, self.info.fps_n, self.info.fps_d)
        G.safe_seek(self._pipe, int(pos_ns), stop, rate=self._rate, accurate=True)

    def set_mute(self, mute: bool):
        self.mute = mute
        if self._pipe:
            vol = self._pipe.get_by_name("vol")
            if vol:
                G.set_prop(vol, "mute", mute)

    def position_ns(self) -> int:
        if not self._pipe:
            return 0
        ok, pos = self._pipe.query_position(Gst.Format.TIME)
        return int(pos) if ok else 0
