"""ParallaxDoF Studio — aplikacja GTK4.

Okno główne: podgląd na żywo (2 widoki, obok siebie lub jeden nad drugim), panele
parametrów A/B, preanaliza głębi/ruchu, eksport (test-run zakresu lub całości) z
korektą parametrów w locie. Wyniki otwierają się w osobnym, pełnoekranowym oknie
przeglądu z podpisami, zaznaczaniem zakresu powtarzania i pętlą.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, Gio, GLib, GObject  # noqa: E402

from . import gsthelpers as G
from . import params as P
from .analysis import AnalysisCache, estimate_bytes
from .gsthelpers import Gst
from .jobs import AnalysisJob, EncodeJob, EncSettings, available_codecs, available_containers
from .media import MediaInfo, probe
from .presets import PresetStore, Settings
from .preview import PreviewEngine
from .simpleplayer import SimplePlayer
from .videosurface import VideoSurface
from .widgets import ParamPanel, TimecodeEntry

APP_ID = "pl.stpf99.parallaxdofgui"
CSS = b"""
.pdof-video { background-color: #101012; }
.pdof-caption {
  color: #f3f3f3; background-color: rgba(0,0,0,0.55);
  padding: 4px 9px; border-radius: 6px; font-weight: 600;
}
.pdof-banner-error { background-color: #4a1414; color: #ffdcdc; padding: 6px 10px; }
.pdof-banner-ok { background-color: #123a1e; color: #d6ffe2; padding: 6px 10px; }
.pdof-dim { opacity: 0.55; }
.pdof-slot-label { font-weight: 700; font-size: 1.05em; }
headerbar { padding-left: 2px; padding-right: 2px; }
"""


def alert(parent, text, detail=""):
    d = Gtk.AlertDialog(message=text, detail=detail, modal=True)
    d.show(parent)


def confirm(parent, text, detail, ok_label, cb):
    d = Gtk.AlertDialog(message=text, detail=detail, modal=True,
                        buttons=["Anuluj", ok_label], cancel_button=0, default_button=0)
    def done(dlg, res):
        try:
            idx = dlg.choose_finish(res)
        except GLib.Error:
            return
        if idx == 1:
            cb()
    d.choose(parent, None, done)


class SlotTab(Gtk.Box):
    """Zakładka parametrów jednego slotu (A lub B): panel + przyciski presetów."""

    def __init__(self, slot: str, specs, presets: PresetStore, on_changed, on_load_preset):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6,
                         margin_start=8, margin_end=8, margin_top=8, margin_bottom=8)
        self.slot = slot
        row = Gtk.Box(spacing=6)
        row.append(Gtk.Label(label=f"Wariant {slot}", css_classes=["pdof-slot-label"], hexpand=True, xalign=0))
        self.preset_combo = Gtk.DropDown.new_from_strings([n for n, _b in presets.names()])
        self.preset_combo.set_hexpand(True)
        row.append(self.preset_combo)
        load_btn = Gtk.Button(label="Wczytaj")
        load_btn.connect("clicked", lambda *_: on_load_preset(
            slot, self.preset_combo.get_selected_item().get_string()))
        row.append(load_btn)
        self.append(row)
        reset_btn = Gtk.Button(label="Przywróć wszystkie domyślne", halign=Gtk.Align.START)
        self.append(reset_btn)
        sw = Gtk.ScrolledWindow(vexpand=True, hscrollbar_policy=Gtk.PolicyType.NEVER)
        self.panel = ParamPanel(specs)
        self.panel.connect("param-changed", lambda _p, n, v: on_changed(slot, n, v))
        reset_btn.connect("clicked", lambda *_: self.panel.reset_all())
        sw.set_child(self.panel)
        self.append(sw)

    def refresh_presets(self, presets: PresetStore):
        names = [n for n, _b in presets.names()]
        cur = self.preset_combo.get_selected_item()
        self.preset_combo.set_model(Gtk.StringList.new(names))
        if cur is not None and cur.get_string() in names:
            self.preset_combo.set_selected(names.index(cur.get_string()))


class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application):
        super().__init__(application=app, title="ParallaxDoF Studio", default_width=1440, default_height=880)
        self.settings = Settings()
        self.presets = PresetStore()
        self.cache = AnalysisCache()
        self.pdof_specs = P.introspect("parallaxdof")
        self.an_specs = P.introspect("depthanalyzer")

        self.info: MediaInfo | None = None
        self.eng: PreviewEngine | None = None
        self.surfaces = [VideoSurface(""), VideoSurface("")]
        self.view_kinds = ["orig", "A"]        # co pokazuje surfaces[0]/[1]
        self.depth_on = True
        self.motion_on = False
        self.an_job: AnalysisJob | None = None
        self.enc_jobs: dict[str, EncodeJob] = {}
        self._seek_dragging = False
        self._pos_timer = None
        self.result_win: "ResultWindow | None" = None

        self._build_ui()
        self._apply_css()
        self.connect("close-request", self._on_close)
        GLib.idle_add(self._maybe_open_last)

    # ── budowa UI ────────────────────────────────────────────────────────────
    def _apply_css(self):
        prov = Gtk.CssProvider()
        prov.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), prov,
                                                   Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def _build_ui(self):
        header = Gtk.HeaderBar()
        self.set_titlebar(header)
        open_btn = Gtk.Button(icon_name="document-open-symbolic", tooltip_text="Otwórz plik wideo")
        open_btn.connect("clicked", self._on_open_clicked)
        header.pack_start(open_btn)
        self.orient_btn = Gtk.ToggleButton(icon_name="view-dual-symbolic",
                                           tooltip_text="Układ: obok siebie / jeden nad drugim")
        self.orient_btn.connect("toggled", self._on_orient_toggled)
        header.pack_start(self.orient_btn)
        self.title_lbl = Gtk.Label(label="ParallaxDoF Studio — brak pliku")
        header.set_title_widget(self.title_lbl)
        self.banner = Gtk.Label(visible=False, wrap=True)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        root.append(self.banner)
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL, position=480, vexpand=True)
        root.append(paned)
        self.set_child(root)

        # ── lewy panel: zakładki ──
        self.stack = Gtk.Stack(vexpand=True, hexpand=True)
        side_switcher = Gtk.StackSidebar(stack=self.stack, width_request=132, hexpand=False)
        side_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, hexpand=True)
        side_box.append(side_switcher)
        side_box.append(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL))
        side_box.append(self.stack)
        side_wrap = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER,
                                       vscrollbar_policy=Gtk.PolicyType.NEVER, hexpand=True)
        side_wrap.set_child(side_box)
        paned.set_start_child(side_wrap)
        paned.set_resize_start_child(True)
        paned.set_shrink_start_child(False)

        self.tab_a = SlotTab("A", self.pdof_specs, self.presets, self._on_param_changed, self._on_load_preset)
        self.tab_b = SlotTab("B", self.pdof_specs, self.presets, self._on_param_changed, self._on_load_preset)
        def _scrolled(w):
            s = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.NEVER)
            s.set_child(w)
            return s
        self.stack.add_titled(self.tab_a, "a", "Wariant A")
        self.stack.add_titled(self.tab_b, "b", "Wariant B")
        self.stack.add_titled(_scrolled(self._build_analysis_page()), "analysis", "Preanaliza")
        self.stack.add_titled(_scrolled(self._build_export_page()), "export", "Eksport")
        self.stack.add_titled(_scrolled(self._build_presets_page()), "presets", "Presety")

        # ── prawa strona: podgląd + transport ──
        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6,
                        margin_start=8, margin_end=8, margin_top=8, margin_bottom=8)
        paned.set_end_child(right)

        view_row = Gtk.Box(spacing=10)
        self.view_combos = []
        for i, lbl in enumerate(("Widok 1", "Widok 2")):
            view_row.append(Gtk.Label(label=lbl))
            combo = Gtk.DropDown.new_from_strings(["Oryginał", "Wariant A", "Wariant B"])
            combo.set_selected(0 if i == 0 else 1)
            combo.connect("notify::selected", self._on_view_combo_changed)
            self.view_combos.append(combo)
            view_row.append(combo)
        view_row.append(Gtk.Box(hexpand=True))
        self.status_lbl = Gtk.Label(label="Otwórz plik wideo, aby zacząć.", xalign=1)
        view_row.append(self.status_lbl)
        right.append(view_row)

        self.video_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4, vexpand=True,
                                 homogeneous=True)
        for s in self.surfaces:
            s.set_hexpand(True); s.set_vexpand(True)
            self.video_box.append(s)
        right.append(self.video_box)

        right.append(self._build_transport())
        right.append(self._build_range_row())

    def _build_transport(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.seek_scale = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL, draw_value=False, hexpand=True)
        self.seek_scale.set_range(0, 1)
        click = Gtk.GestureClick()
        click.connect("pressed", lambda *_: setattr(self, "_seek_dragging", True))
        click.connect("released", self._on_seek_released)
        self.seek_scale.add_controller(click)
        box.append(self.seek_scale)

        row = Gtk.Box(spacing=6)
        self.step_back = Gtk.Button(icon_name="media-skip-backward-symbolic", tooltip_text="Poprzednia klatka")
        self.step_back.connect("clicked", lambda *_: self.eng and (self.eng.step(-1), self._sync_seek_now()))
        self.play_btn = Gtk.Button(icon_name="media-playback-start-symbolic", tooltip_text="Odtwórz / pauza")
        self.play_btn.connect("clicked", lambda *_: self.eng and self.eng.toggle())
        self.step_fwd = Gtk.Button(icon_name="media-skip-forward-symbolic", tooltip_text="Następna klatka")
        self.step_fwd.connect("clicked", lambda *_: self.eng and (self.eng.step(1), self._sync_seek_now()))
        for b in (self.step_back, self.play_btn, self.step_fwd):
            row.append(b)
        self.loop_btn = Gtk.ToggleButton(icon_name="media-playlist-repeat-symbolic", tooltip_text="Pętla",
                                         active=True)
        self.loop_btn.connect("toggled", lambda b: self.eng and setattr(self.eng, "loop", b.get_active()))
        row.append(self.loop_btn)
        self.mute_btn = Gtk.ToggleButton(icon_name="audio-volume-muted-symbolic", tooltip_text="Dźwięk",
                                         active=True)
        self.mute_btn.connect("toggled", lambda b: self.eng and self.eng.set_mute(b.get_active()))
        row.append(self.mute_btn)
        row.append(Gtk.Label(label="Prędkość"))
        self.rate_combo = Gtk.DropDown.new_from_strings(["0.25×", "0.5×", "1×", "1.5×", "2×"])
        self.rate_combo.set_selected(2)
        self.rate_combo.connect("notify::selected", self._on_rate_changed)
        row.append(self.rate_combo)
        self.pos_lbl = Gtk.Label(label="00:00.000 / 00:00.000", xalign=1, hexpand=True)
        row.append(self.pos_lbl)
        box.append(row)
        return box

    def _build_range_row(self) -> Gtk.Widget:
        box = Gtk.Box(spacing=8)
        box.append(Gtk.Label(label="Zakres testu:  OD"))
        self.tc_from = TimecodeEntry(0.0)
        self.tc_from.connect("changed-sec", self._on_range_changed)
        box.append(self.tc_from)
        box.append(Gtk.Label(label="DO"))
        self.tc_to = TimecodeEntry(0.0)
        self.tc_to.connect("changed-sec", self._on_range_changed)
        box.append(self.tc_to)
        set_from = Gtk.Button(label="OD ⟵ pozycja", tooltip_text="Ustaw początek zakresu z bieżącej pozycji")
        set_from.connect("clicked", lambda *_: self._range_from_position(True))
        box.append(set_from)
        set_to = Gtk.Button(label="DO ⟵ pozycja", tooltip_text="Ustaw koniec zakresu z bieżącej pozycji")
        set_to.connect("clicked", lambda *_: self._range_from_position(False))
        box.append(set_to)
        self.range_lbl = Gtk.Label(label="", xalign=1, hexpand=True)
        box.append(self.range_lbl)
        return box

    def _build_analysis_page(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10,
                      margin_start=10, margin_end=10, margin_top=10, margin_bottom=10)
        box.append(Gtk.Label(xalign=0, wrap=True, label=
            "Preanaliza liczy mapę głębi (i opcjonalnie realny ruch — optical flow) dla "
            "wybranego zakresu i zapisuje ją w podręcznym cache. Parametry pasm głębi, "
            "wiggle 3D i część wzmocnień saliency wymagają preanalizy głębi; kontrast od "
            "prędkości wymaga preanalizy ruchu."))
        self.depth_chk = Gtk.CheckButton(label="Użyj mapy głębi w efekcie (depth-file)", active=True)
        self.motion_chk = Gtk.CheckButton(label="Użyj realnego ruchu w efekcie (motion-file, Farneback)")
        self.depth_chk.connect("toggled", self._on_data_mode_toggled)
        self.motion_chk.connect("toggled", self._on_data_mode_toggled)
        box.append(self.depth_chk)
        box.append(self.motion_chk)

        grid = Gtk.Grid(row_spacing=6, column_spacing=10)
        self.an_rows = {}
        for i, name in enumerate(("proc-scale", "smooth-ksize", "flow-weight", "edge-weight", "motion-max-mag")):
            spec = self.an_specs[name]
            label, blurb = P.ANALYZER_META[name]
            grid.attach(Gtk.Label(label=label, xalign=0, tooltip_text=blurb), 0, i, 1, 1)
            spin = Gtk.SpinButton()
            spin.set_range(spec.minimum, spec.maximum)
            spin.set_increments(spec.step, spec.step * 5)
            spin.set_digits(spec.digits)
            spin.set_value(spec.default)
            grid.attach(spin, 1, i, 1, 1)
            self.an_rows[name] = spin
        box.append(grid)

        run_row = Gtk.Box(spacing=8)
        self.an_run_btn = Gtk.Button(label="Uruchom analizę zakresu testu")
        self.an_run_btn.connect("clicked", lambda *_: self._start_analysis(full=False))
        self.an_run_full_btn = Gtk.Button(label="Analizuj cały plik")
        self.an_run_full_btn.connect("clicked", lambda *_: self._start_analysis(full=True))
        self.an_cancel_btn = Gtk.Button(label="Anuluj", sensitive=False)
        self.an_cancel_btn.connect("clicked", lambda *_: self.an_job and self.an_job.cancel())
        run_row.append(self.an_run_btn); run_row.append(self.an_run_full_btn); run_row.append(self.an_cancel_btn)
        box.append(run_row)
        self.an_progress = Gtk.ProgressBar(show_text=True)
        box.append(self.an_progress)
        self.an_status = Gtk.Label(xalign=0, wrap=True, label="Brak analizy dla bieżącego pliku.")
        box.append(self.an_status)

        cache_row = Gtk.Box(spacing=8)
        self.cache_lbl = Gtk.Label(xalign=0, hexpand=True)
        cache_row.append(self.cache_lbl)
        clear_btn = Gtk.Button(label="Wyczyść cache preanalizy")
        clear_btn.connect("clicked", self._on_clear_cache)
        cache_row.append(clear_btn)
        box.append(cache_row)
        self._refresh_cache_label()
        return box

    def _build_export_page(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10,
                      margin_start=10, margin_end=10, margin_top=10, margin_bottom=10)
        box.append(Gtk.Label(xalign=0, label="Co zakodować:", css_classes=["pdof-slot-label"]))
        self.exp_chk = {
            "O": Gtk.CheckButton(label="Oryginał (bez efektu)"),
            "A": Gtk.CheckButton(label="Wariant A", active=True),
            "B": Gtk.CheckButton(label="Wariant B"),
        }
        for c in self.exp_chk.values():
            box.append(c)

        self.exp_full_chk = Gtk.CheckButton(label="Cały plik (ignoruj zakres testu)")
        box.append(self.exp_full_chk)

        grid = Gtk.Grid(row_spacing=6, column_spacing=10)
        r = 0
        grid.attach(Gtk.Label(label="Kodek wideo", xalign=0), 0, r, 1, 1)
        _codecs = [c for c in available_codecs() if not c.upper().startswith("VA")] or ["x264enc"]
        self.codec_combo = Gtk.DropDown.new_from_strings(_codecs)
        grid.attach(self.codec_combo, 1, r, 1, 1); r += 1
        grid.attach(Gtk.Label(label="Kontener", xalign=0), 0, r, 1, 1)
        self.container_combo = Gtk.DropDown.new_from_strings(available_containers() or ["mp4"])
        grid.attach(self.container_combo, 1, r, 1, 1); r += 1
        grid.attach(Gtk.Label(label="Sterowanie jakością", xalign=0), 0, r, 1, 1)
        self.rc_combo = Gtk.DropDown.new_from_strings(["Jakość (quantizer)", "Docelowy bitrate"])
        self.rc_combo.set_selected(1)
        grid.attach(self.rc_combo, 1, r, 1, 1); r += 1
        grid.attach(Gtk.Label(label="Jakość quantizer (niżej = lepiej)", xalign=0), 0, r, 1, 1)
        self.quality_spin = Gtk.SpinButton()
        self.quality_spin.set_range(0, 50); self.quality_spin.set_increments(1, 5)
        self.quality_spin.set_value(23)
        grid.attach(self.quality_spin, 1, r, 1, 1); r += 1
        grid.attach(Gtk.Label(label="Bitrate (kb/s)", xalign=0), 0, r, 1, 1)
        self.bitrate_spin = Gtk.SpinButton()
        self.bitrate_spin.set_range(200, 100000); self.bitrate_spin.set_increments(500, 2000)
        self.bitrate_spin.set_value(4000)
        grid.attach(self.bitrate_spin, 1, r, 1, 1); r += 1
        grid.attach(Gtk.Label(label="Prędkość kodowania", xalign=0), 0, r, 1, 1)
        self.speed_combo = Gtk.DropDown.new_from_strings(["Szybko", "Średnio", "Wolno"])
        self.speed_combo.set_selected(1)
        grid.attach(self.speed_combo, 1, r, 1, 1); r += 1
        grid.attach(Gtk.Label(label="Audio", xalign=0), 0, r, 1, 1)
        self.audio_combo = Gtk.DropDown.new_from_strings(["AAC", "Bez dźwięku"])
        grid.attach(self.audio_combo, 1, r, 1, 1); r += 1
        box.append(grid)

        out_row = Gtk.Box(spacing=8)
        self.out_dir_lbl = Gtk.Label(label="(wybierz folder wyjściowy)", xalign=0, hexpand=True, ellipsize=3)
        out_row.append(self.out_dir_lbl)
        out_btn = Gtk.Button(label="Folder wyjściowy…")
        out_btn.connect("clicked", self._on_choose_outdir)
        out_row.append(out_btn)
        box.append(out_row)

        act_row = Gtk.Box(spacing=8)
        self.enc_start_btn = Gtk.Button(label="Start (test-run)")
        self.enc_start_btn.add_css_class("suggested-action")
        self.enc_start_btn.connect("clicked", lambda *_: self._start_encode())
        act_row.append(self.enc_start_btn)
        self.enc_cancel_btn = Gtk.Button(label="Anuluj wszystko", sensitive=False)
        self.enc_cancel_btn.connect("clicked", self._on_cancel_encode)
        act_row.append(self.enc_cancel_btn)
        self.view_result_chk = Gtk.CheckButton(label="Pokaż wynik pełnoekranowo po zakończeniu", active=True)
        act_row.append(self.view_result_chk)
        box.append(act_row)

        self.enc_progress: dict[str, Gtk.ProgressBar] = {}
        self.enc_prog_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.append(self.enc_prog_box)
        self.enc_log = Gtk.Label(xalign=0, wrap=True, label="")
        box.append(self.enc_log)
        return box

    def _build_presets_page(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                      margin_start=10, margin_end=10, margin_top=10, margin_bottom=10)
        box.append(Gtk.Label(xalign=0, wrap=True, label=
            "Presety zapisują wartości suwaków efektu (nie preanalizy). Wczytuj je do "
            "Wariantu A lub B z odpowiedniej zakładki."))
        sw = Gtk.ScrolledWindow(vexpand=True)
        self.preset_list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.SINGLE)
        sw.set_child(self.preset_list)
        box.append(sw)
        self._refresh_preset_list()

        name_row = Gtk.Box(spacing=6)
        self.preset_name_entry = Gtk.Entry(placeholder_text="Nazwa nowego presetu…", hexpand=True)
        name_row.append(self.preset_name_entry)
        box.append(name_row)
        btn_row = Gtk.Box(spacing=6)
        save_a = Gtk.Button(label="Zapisz A jako…")
        save_a.connect("clicked", lambda *_: self._save_preset("A"))
        save_b = Gtk.Button(label="Zapisz B jako…")
        save_b.connect("clicked", lambda *_: self._save_preset("B"))
        del_btn = Gtk.Button(label="Usuń zaznaczony")
        del_btn.connect("clicked", self._on_delete_preset)
        btn_row.append(save_a); btn_row.append(save_b); btn_row.append(del_btn)
        box.append(btn_row)
        return box

    def _refresh_preset_list(self):
        child = self.preset_list.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self.preset_list.remove(child)
            child = nxt
        for name, builtin in self.presets.names():
            row = Gtk.Box(spacing=6, margin_start=6, margin_end=6, margin_top=4, margin_bottom=4)
            row.append(Gtk.Label(label=name, xalign=0, hexpand=True))
            if builtin:
                row.append(Gtk.Label(label="wbudowany", css_classes=["dim-label"]))
            desc = self.presets.description(name)
            lb_row = Gtk.ListBoxRow(child=row, tooltip_text=desc)
            lb_row.pdof_name = name
            self.preset_list.append(lb_row)

    # ── plik / otwieranie ────────────────────────────────────────────────────
    def _maybe_open_last(self):
        last = self.settings.get("last_video")
        if last and os.path.exists(last):
            self._open_path(last)
        return False

    def _on_open_clicked(self, *_a):
        d = Gtk.FileDialog(title="Otwórz plik wideo")
        f = Gtk.FileFilter(); f.add_mime_type("video/*"); f.set_name("Wideo")
        store = Gio.ListStore.new(Gtk.FileFilter); store.append(f)
        d.set_filters(store)
        def done(dlg, res):
            try:
                gfile = dlg.open_finish(res)
            except GLib.Error:
                return
            if gfile:
                self._open_path(gfile.get_path())
        d.open(self, None, done)

    def _open_path(self, path: str):
        try:
            info = probe(path)
        except Exception as e:  # noqa: BLE001
            alert(self, "Nie można odczytać pliku", str(e))
            return
        self.info = info
        self.settings.set("last_video", path)
        self.title_lbl.set_label(f"{Path(path).name} — {info.label()} — {info.duration:.2f}s")
        if info.notes:
            self._show_banner(" ".join(info.notes), error=False)
        self.tc_from.fps = self.tc_to.fps = info.fps
        self.tc_from.set_seconds(0.0)
        self.tc_to.set_seconds(info.duration)
        self.range_lbl.set_label(self._range_desc())
        self.seek_scale.set_range(0, info.duration)
        default_dir = Path(path).parent / "pdof_out"
        self.out_dir = self.settings.get("out_dir") or str(default_dir)
        self.out_dir_lbl.set_label(self.out_dir)
        self.eng = PreviewEngine(info, self.surfaces)
        self.eng.on_state = self._on_engine_state
        self.eng.on_error = self._on_engine_error
        self.eng.loop = self.loop_btn.get_active()
        self.eng.mute = self.mute_btn.get_active()
        self._push_params_to_engine()
        self._apply_view_kinds()
        self._update_analysis_status()
        self.status_lbl.set_label("Gotowe.")
        if self._pos_timer is None:
            self._pos_timer = GLib.timeout_add(120, self._tick_position)

    # ── zakres testu ─────────────────────────────────────────────────────────
    def _range_desc(self) -> str:
        if not self.info:
            return ""
        i0, i1 = self.info.t_to_frame(self.tc_from.get_seconds()), self.info.t_to_frame(self.tc_to.get_seconds())
        return f"{i1 - i0} klatek ({(i1 - i0) / self.info.fps:.2f} s)"

    def _on_range_changed(self, *_a):
        if not self.info or not self.eng:
            return
        i0 = self.info.t_to_frame(self.tc_from.get_seconds())
        i1 = self.info.t_to_frame(self.tc_to.get_seconds())
        if i1 <= i0:
            i1 = min(self.info.frames, i0 + 1)
            self.tc_to.set_seconds(self.info.frame_to_t(i1))
        self.eng.i0, self.eng.i1 = i0, i1
        self.range_lbl.set_label(self._range_desc())
        self._update_analysis_status()
        was_playing = self.eng.state == "playing"
        self.eng.launch(None, was_playing)

    def _range_from_position(self, is_from: bool):
        if not self.eng:
            return
        sec = self.eng.position_ns() / G.SECOND
        (self.tc_from if is_from else self.tc_to).set_seconds(sec, emit=True)

    # ── widoki / orientacja ──────────────────────────────────────────────────
    def _apply_view_kinds(self):
        if not self.eng:
            return
        self.eng.views = list(self.view_kinds)
        for surf, kind in zip(self.surfaces, self.view_kinds):
            surf.set_caption({"orig": "Oryginał", "A": "Wariant A", "B": "Wariant B"}[kind])
        was_playing = self.eng.state == "playing"
        self.eng.launch(None, was_playing)

    def _on_view_combo_changed(self, combo, _p):
        idx = self.view_combos.index(combo)
        sel = combo.get_selected()
        self.view_kinds[idx] = ["orig", "A", "B"][sel]
        self._apply_view_kinds()

    def _on_orient_toggled(self, btn):
        self.video_box.set_orientation(
            Gtk.Orientation.VERTICAL if btn.get_active() else Gtk.Orientation.HORIZONTAL)

    # ── transport ────────────────────────────────────────────────────────────
    def _on_rate_changed(self, combo, _p):
        rate = [0.25, 0.5, 1.0, 1.5, 2.0][combo.get_selected()]
        if self.eng:
            self.eng.set_rate(rate)

    def _on_seek_released(self, _g, _n, x, _y):
        if self.eng:
            frac = min(max(x / max(1, self.seek_scale.get_width()), 0), 1)
            pos_ns = int(self.seek_scale.get_adjustment().get_value() * G.SECOND)
            self.eng.seek(pos_ns)
        self._seek_dragging = False

    def _sync_seek_now(self):
        if self.eng:
            self.seek_scale.set_value(self.eng.position_ns() / G.SECOND)

    def _tick_position(self):
        if self.eng and self.info:
            pos = self.eng.position_ns() / G.SECOND
            if not self._seek_dragging:
                self.seek_scale.set_value(pos)
            self.pos_lbl.set_label(f"{G.fmt_tc(pos)} / {G.fmt_tc(self.info.duration)}")
        return True

    def _on_engine_state(self, st):
        icon = {"playing": "media-playback-pause-symbolic"}.get(st, "media-playback-start-symbolic")
        self.play_btn.set_icon_name(icon)
        busy = st == "loading"
        for w in (self.seek_scale, self.step_back, self.step_fwd):
            w.set_sensitive(not busy)

    def _on_engine_error(self, msg):
        self._show_banner(f"Błąd podglądu: {msg}", error=True)

    def _show_banner(self, text, error=True):
        self.banner.set_label(text)
        self.banner.set_visible(True)
        self.banner.set_css_classes(["pdof-banner-error" if error else "pdof-banner-ok"])
        GLib.timeout_add_seconds(6, lambda: (self.banner.set_visible(False), False)[1])

    # ── parametry ────────────────────────────────────────────────────────────
    def _push_params_to_engine(self):
        if not self.eng:
            return
        self.eng.params["A"] = P.clamp(self.pdof_specs, self.tab_a.panel.values())
        self.eng.params["B"] = P.clamp(self.pdof_specs, self.tab_b.panel.values())

    def _on_param_changed(self, slot, name, value):
        job = self.enc_jobs.get(slot)
        if job is not None and not job.finished:
            job.set_param(name, value)             # korekta w locie PODCZAS kodowania
        elif self.eng is not None:
            self.eng.set_param(slot, name, value)   # korekta w locie w podglądzie
        self._update_analysis_status()

    def _on_load_preset(self, slot, name):
        vals = self.presets.get(name)
        panel = self.tab_a.panel if slot == "A" else self.tab_b.panel
        panel.reset_all()
        panel.apply_values(P.clamp(self.pdof_specs, vals))
        self._push_params_to_engine()
        self._update_analysis_status()

    def _save_preset(self, slot):
        name = self.preset_name_entry.get_text().strip()
        if not name:
            alert(self, "Podaj nazwę presetu."); return
        panel = self.tab_a.panel if slot == "A" else self.tab_b.panel
        dflt = P.defaults(self.pdof_specs)
        changed = {n: v for n, v in panel.values().items() if abs(v - dflt[n]) > 1e-9}
        self.presets.save(name, changed, f"Zapisany z Wariantu {slot}.")
        self.preset_name_entry.set_text("")
        self._refresh_preset_list()
        self.tab_a.refresh_presets(self.presets)
        self.tab_b.refresh_presets(self.presets)

    def _on_delete_preset(self, *_a):
        row = self.preset_list.get_selected_row()
        if row is None:
            return
        name = row.pdof_name
        if self.presets.is_builtin(name):
            alert(self, "Nie można usunąć wbudowanego presetu."); return
        self.presets.delete(name)
        self._refresh_preset_list()
        self.tab_a.refresh_presets(self.presets)
        self.tab_b.refresh_presets(self.presets)

    # ── preanaliza ───────────────────────────────────────────────────────────
    def _an_params(self) -> dict:
        return {n: s.get_value() for n, s in self.an_rows.items()}

    def _wanted_data_mode(self) -> str:
        d, m = self.depth_chk.get_active(), self.motion_chk.get_active()
        if d and m:
            return "depth+motion"
        if d:
            return "depth"
        if m:
            return "motion"
        return "realtime"

    def _on_data_mode_toggled(self, *_a):
        self._update_analysis_status()
        if self.eng:
            self.eng.data_mode = self._wanted_data_mode()
            was_playing = self.eng.state == "playing"
            self.eng.launch(None, was_playing)

    def _current_needs(self) -> set:
        vals = {**self.tab_a.panel.values(), **{f"b:{k}": v for k, v in self.tab_b.panel.values().items()}}
        need = P.needs_of_params(self.tab_a.panel.values(), self.pdof_specs)
        need |= P.needs_of_params(self.tab_b.panel.values(), self.pdof_specs)
        return need

    def _update_analysis_status(self):
        self.tab_a.panel.set_sensitive_for(set() if self.depth_chk.get_active() and self.motion_chk.get_active()
                                           else ({"depth", "motion"} - self._enabled_sources()))
        self.tab_b.panel.set_sensitive_for(set() if self.depth_chk.get_active() and self.motion_chk.get_active()
                                           else ({"depth", "motion"} - self._enabled_sources()))
        if not self.info or not self.eng:
            return
        mode = self._wanted_data_mode()
        if mode == "realtime":
            self.an_status.set_label("Tryb realtime — preanaliza nieużywana przez efekt.")
            return
        need_motion = "motion" in mode
        meta = self.cache.find(self.info, self._an_params(), need_motion, self.an_rows["motion-max-mag"].get_value(),
                               self.eng.i0, self.eng.i1)
        if meta:
            self.an_status.set_label(f"OK — cache pokrywa zakres testu: {meta.describe()}.")
            if hasattr(self.eng, "set_data_files"):
                self.eng.set_data_files(meta.to_files())
        else:
            self.an_status.set_label("Brak preanalizy pokrywającej bieżący zakres testu z tymi parametrami "
                                     "analizatora — uruchom analizę.")
            if hasattr(self.eng, "set_data_files"):
                self.eng.set_data_files({})

    def _enabled_sources(self) -> set:
        s = set()
        if self.depth_chk.get_active():
            s.add("depth")
        if self.motion_chk.get_active():
            s.add("motion")
        return s

    def _start_analysis(self, full: bool):
        if not self.info:
            return
        if self.an_job is not None and not self.an_job.finished:
            return
        i0, i1 = (0, self.info.frames) if full else (self.eng.i0, self.eng.i1)
        need_motion = self.motion_chk.get_active()
        an_params = self._an_params()
        max_mag = self.an_rows["motion-max-mag"].get_value()
        self.an_run_btn.set_sensitive(False)
        self.an_run_full_btn.set_sensitive(False)
        self.an_cancel_btn.set_sensitive(True)
        self.an_progress.set_fraction(0)
        t0 = time.monotonic()

        def prog(p, fps, eta):
            self.an_progress.set_fraction(p)
            eta_s = f", ETA {eta:.0f}s" if eta else ""
            self.an_progress.set_text(f"{p*100:.0f}%  ({fps:.1f} kl/s{eta_s})")

        def done(job, ok, err):
            self.an_run_btn.set_sensitive(True)
            self.an_run_full_btn.set_sensitive(True)
            self.an_cancel_btn.set_sensitive(False)
            if ok:
                self.an_status.set_label(f"Gotowe: {job.meta.describe()}  "
                                         f"({time.monotonic()-t0:.1f}s).")
                self._refresh_cache_label()
                self._update_analysis_status()
            else:
                self._show_banner(f"Analiza nieudana: {err}", error=True)
            self.an_job = None

        self.an_job = AnalysisJob(self.info, i0, i1, an_params, need_motion, max_mag, self.cache,
                                  on_progress=prog, on_done=done)
        self.an_job.start()

    def _on_clear_cache(self, *_a):
        def go():
            self.cache.clear()
            self._refresh_cache_label()
            self._update_analysis_status()
        confirm(self, "Wyczyścić cały cache preanalizy?", "Usunie wszystkie zapisane mapy głębi/ruchu z dysku.",
               "Wyczyść", go)

    def _refresh_cache_label(self):
        n = self.cache.size_bytes() / (1024 * 1024)
        self.cache_lbl.set_label(f"Cache preanalizy: {n:.1f} MB")

    # ── eksport ──────────────────────────────────────────────────────────────
    def _on_choose_outdir(self, *_a):
        d = Gtk.FileDialog(title="Folder wyjściowy")
        def done(dlg, res):
            try:
                gfile = dlg.select_folder_finish(res)
            except GLib.Error:
                return
            if gfile:
                self.out_dir = gfile.get_path()
                self.out_dir_lbl.set_label(self.out_dir)
                self.settings.set("out_dir", self.out_dir)
        d.select_folder(self, None, done)

    def _enc_settings(self) -> EncSettings:
        codecs = [c for c in (available_codecs() or ["x264enc"]) if not c.upper().startswith("VA")] or ["x264enc"]
        containers = available_containers() or ["mp4"]
        codec = codecs[min(self.codec_combo.get_selected(), len(codecs) - 1)]
        container = "mp4"  # zawsze MP4
        speed = ["fast", "medium", "slow"][min(self.speed_combo.get_selected(), 2)]
        audio = ["aac", "none"][min(self.audio_combo.get_selected(), 1)]
        rc = "quality" if self.rc_combo.get_selected() == 0 else "bitrate"
        return EncSettings(codec=codec, container=container, rc=rc,
                           quality=int(self.quality_spin.get_value()),
                           bitrate=int(self.bitrate_spin.get_value()), speed=speed, audio=audio)

    def _start_encode(self):
        if not self.info:
            return
        targets = [t for t, c in self.exp_chk.items() if c.get_active()]
        if not targets:
            alert(self, "Zaznacz co najmniej jeden wariant do zakodowania."); return
        i0, i1 = (0, self.info.frames) if self.exp_full_chk.get_active() else (self.eng.i0, self.eng.i1)
        mode = self._wanted_data_mode()
        data = None
        if mode != "realtime" and any(t in ("A", "B") for t in targets):
            need_motion = "motion" in mode
            meta = self.cache.find(self.info, self._an_params(), need_motion,
                                   self.an_rows["motion-max-mag"].get_value(), i0, i1)
            if meta is None:
                alert(self, "Brak preanalizy dla wybranego zakresu",
                     "Uruchom preanalizę (zakładka Preanaliza) dla tego zakresu i tych parametrów, "
                     "albo wyłącz depth-file/motion-file.")
                return
            data = meta.to_files()
        es = self._enc_settings()
        Path(self.out_dir).mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        self.enc_prog_box_clear()
        self.enc_start_btn.set_sensitive(False)
        self.enc_cancel_btn.set_sensitive(True)
        for t in targets:
            fname = f"{Path(self.info.path).stem}_{t}_{stamp}.{es.container}"
            out_path = str(Path(self.out_dir) / fname)
            params_t = P.clamp(self.pdof_specs, (self.tab_a if t == "A" else self.tab_b).panel.values()) if t != "O" else {}
            pb = Gtk.ProgressBar(show_text=True)
            row = Gtk.Box(spacing=6)
            row.append(Gtk.Label(label=f"Wariant {t}:", width_chars=10, xalign=0))
            row.append(pb)
            self.enc_prog_box.append(row)
            self.enc_progress[t] = pb
            preset_note = self._preset_note(t)
            self._launch_encode(t, i0, i1, params_t, mode, data, es, out_path, preset_note)

    def enc_prog_box_clear(self):
        child = self.enc_prog_box.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self.enc_prog_box.remove(child)
            child = nxt
        self.enc_progress.clear()
        self.enc_log.set_label("")

    def _preset_note(self, slot) -> str:
        combo = (self.tab_a if slot == "A" else self.tab_b).preset_combo if slot in ("A", "B") else None
        if combo is None:
            return "bez efektu"
        item = combo.get_selected_item()
        return item.get_string() if item else ""

    def _launch_encode(self, target, i0, i1, params_t, mode, data, es, out_path, note):
        t0 = time.monotonic()

        def prog(p, fps, eta):
            pb = self.enc_progress.get(target)
            if pb:
                eta_s = f", ETA {eta:.0f}s" if eta else ""
                pb.set_fraction(p)
                pb.set_text(f"{p*100:.0f}%  {fps:.1f} kl/s{eta_s}")

        def done(job, ok, err):
            pb = self.enc_progress.get(target)
            if pb:
                pb.set_fraction(1.0 if ok else pb.get_fraction())
                pb.set_text("Gotowe" if ok else f"Błąd: {err}")
            self.enc_jobs.pop(target, None)
            if ok:
                self._append_log(f"Wariant {target}: zapisano {out_path} "
                                 f"({time.monotonic()-t0:.1f}s).")
                self._on_export_done(target, out_path, note)
            else:
                self._append_log(f"Wariant {target}: błąd — {err}")
            if not self.enc_jobs:
                self.enc_start_btn.set_sensitive(True)
                self.enc_cancel_btn.set_sensitive(False)

        job = EncodeJob(self.info, i0, i1, target, params_t, mode if target != "O" else "realtime",
                        data, es, out_path, on_progress=prog, on_done=done,
                        meta_extra={"preset_note": note})
        self.enc_jobs[target] = job
        job.start()

    def _append_log(self, text):
        cur = self.enc_log.get_label()
        self.enc_log.set_label((cur + "\n" + text).strip())

    def _on_cancel_encode(self, *_a):
        for job in list(self.enc_jobs.values()):
            job.cancel()

    def _on_export_done(self, target, path, note):
        self._done_results = getattr(self, "_done_results", [])
        label = {"O": "Oryginał", "A": "Wariant A", "B": "Wariant B"}[target]
        caption = f"{label} — {note}" if note and note != "Domyślne" else label
        self._done_results.append({"label": caption, "path": path})
        if self.view_result_chk.get_active() and not self.enc_jobs:
            self._open_result_window(self._done_results)
            self._done_results = []

    def _open_result_window(self, items):
        if self.result_win is not None:
            self.result_win.close()
        self.result_win = ResultWindow(self.get_application(), items)
        self.result_win.present()

    # ── zamykanie ────────────────────────────────────────────────────────────
    def _on_close(self, *_a):
        if self.eng:
            self.eng.stop()
        for job in list(self.enc_jobs.values()):
            job.cancel()
        if self.an_job:
            self.an_job.cancel()
        return False


class ResultWindow(Gtk.Window):
    """Pełnoekranowy przegląd zakodowanych wyników: podpisy, zaznaczanie zakresu
    powtarzania (IN/OUT), pętla, sterowanie klatka po klatce, wyjście klawiszem Esc."""

    def __init__(self, app: Gtk.Application, items: list[dict]):
        super().__init__(application=app, title="ParallaxDoF Studio — wynik", default_width=1200, default_height=800)
        self.items = items
        self.players: list[SimplePlayer] = []
        self.surfaces: list[VideoSurface] = []
        self.info0: MediaInfo | None = None

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.set_child(root)
        top = Gtk.Box(spacing=8, margin_start=8, margin_end=8, margin_top=8)
        top.append(Gtk.Label(label=" / ".join(i["label"] for i in items), hexpand=True, xalign=0,
                             css_classes=["pdof-slot-label"]))
        exit_btn = Gtk.Button(icon_name="window-close-symbolic", tooltip_text="Zamknij (Esc)")
        exit_btn.connect("clicked", lambda *_: self.close())
        top.append(exit_btn)
        root.append(top)

        video_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4, vexpand=True, homogeneous=True)
        root.append(video_row)
        for it in items:
            surf = VideoSurface(it["label"])
            surf.set_hexpand(True); surf.set_vexpand(True)
            video_row.append(surf)
            self.surfaces.append(surf)
            info = probe(it["path"])
            if self.info0 is None:
                self.info0 = info
            pl = SimplePlayer(info, surf, mute=(len(self.players) > 0))
            pl.loop = True
            self.players.append(pl)

        root.append(self._build_transport())

        key = Gtk.EventControllerKey()
        key.connect("key-pressed", self._on_key)
        self.add_controller(key)
        self.connect("close-request", self._on_close)

        self._dragging = False
        GLib.idle_add(self._start_all)
        self._timer = GLib.timeout_add(120, self._tick)
        self.fullscreen()

    def _build_transport(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4,
                      margin_start=8, margin_end=8, margin_bottom=8)
        self.seek = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL, draw_value=False, hexpand=True)
        click = Gtk.GestureClick()
        click.connect("pressed", lambda *_: setattr(self, "_dragging", True))
        click.connect("released", self._on_seek_released)
        self.seek.add_controller(click)
        box.append(self.seek)

        row = Gtk.Box(spacing=8)
        for icon, cb in (("media-skip-backward-symbolic", lambda: self._step(-1)),
                         ("media-playback-start-symbolic", lambda: self._toggle()),
                         ("media-skip-forward-symbolic", lambda: self._step(1))):
            b = Gtk.Button(icon_name=icon)
            b.connect("clicked", lambda *_a, cb=cb: cb())
            row.append(b)
            if icon == "media-playback-start-symbolic":
                self.play_btn = b
        self.loop_btn = Gtk.ToggleButton(icon_name="media-playlist-repeat-symbolic", active=True,
                                         tooltip_text="Powtarzaj zaznaczony zakres")
        self.loop_btn.connect("toggled", lambda b: self._set_loop(b.get_active()))
        row.append(self.loop_btn)
        self.mute_btn = Gtk.ToggleButton(icon_name="audio-volume-high-symbolic", active=False,
                                         tooltip_text="Wycisz")
        self.mute_btn.connect("toggled", lambda b: self._set_mute(b.get_active()))
        row.append(self.mute_btn)

        row.append(Gtk.Label(label="Powtarzaj: OD"))
        self.tc_in = TimecodeEntry(0.0)
        self.tc_in.connect("changed-sec", lambda *_: self._set_inout())
        row.append(self.tc_in)
        row.append(Gtk.Label(label="DO"))
        self.tc_out = TimecodeEntry(0.0)
        self.tc_out.connect("changed-sec", lambda *_: self._set_inout())
        row.append(self.tc_out)
        set_in = Gtk.Button(label="IN ⟵", tooltip_text="Ustaw początek z bieżącej pozycji")
        set_in.connect("clicked", lambda *_: self._mark(True))
        row.append(set_in)
        set_out = Gtk.Button(label="OUT ⟵", tooltip_text="Ustaw koniec z bieżącej pozycji")
        set_out.connect("clicked", lambda *_: self._mark(False))
        row.append(set_out)

        self.pos_lbl = Gtk.Label(label="00:00.000 / 00:00.000", hexpand=True, xalign=1)
        row.append(self.pos_lbl)
        box.append(row)
        return box

    def _start_all(self):
        if self.info0:
            self.seek.set_range(0, self.info0.duration)
            self.tc_in.fps = self.tc_out.fps = self.info0.fps
            self.tc_out.set_seconds(self.info0.duration)
        for p in self.players:
            p.play()
        return False

    def _toggle(self):
        for p in self.players:
            p.toggle()
        icon = "media-playback-pause-symbolic" if self.players[0].state == "playing" else "media-playback-start-symbolic"
        # stan pierwszego gracza wystarczy jako referencja UI (wszyscy sterowani razem)
        GLib.timeout_add(60, lambda: (self.play_btn.set_icon_name(
            "media-playback-pause-symbolic" if self.players[0].state == "playing"
            else "media-playback-start-symbolic"), False)[1])

    def _step(self, n):
        for p in self.players:
            p.step(n)

    def _set_loop(self, v):
        for p in self.players:
            p.loop = v

    def _set_mute(self, v):
        for i, p in enumerate(self.players):
            p.set_mute(v if i == 0 else True)   # tylko pierwszy odtwarza dźwięk, by uniknąć nakładania

    def _mark(self, is_in):
        sec = self.players[0].position_ns() / G.SECOND
        (self.tc_in if is_in else self.tc_out).set_seconds(sec, emit=True)

    def _set_inout(self):
        if not self.info0:
            return
        i0 = self.info0.t_to_frame(self.tc_in.get_seconds())
        i1 = self.info0.t_to_frame(self.tc_out.get_seconds())
        if i1 <= i0:
            i1 = min(self.info0.frames, i0 + 1)
        for p in self.players:
            p.set_in(i0); p.set_out(i1)
            p.launch(p.mid(i0), p.state == "playing")

    def _on_seek_released(self, _g, _n, x, _y):
        if self.players:
            pos_ns = int(self.seek.get_adjustment().get_value() * G.SECOND)
            for p in self.players:
                p.seek(pos_ns)
        self._dragging = False

    def _tick(self):
        if self.players and self.info0:
            pos = self.players[0].position_ns() / G.SECOND
            if not self._dragging:
                self.seek.set_value(pos)
            self.pos_lbl.set_label(f"{G.fmt_tc(pos)} / {G.fmt_tc(self.info0.duration)}")
        return True

    def _on_key(self, _c, keyval, _code, _state):
        name = Gdk.keyval_name(keyval)
        if name == "Escape":
            self.close(); return True
        if name == "space":
            self._toggle(); return True
        if name == "Left":
            self._step(-1); return True
        if name == "Right":
            self._step(1); return True
        return False

    def _on_close(self, *_a):
        for p in self.players:
            p.teardown()
        return False
